<?php return array (
  'backend.roles-table' => 'App\\Http\\Livewire\\Backend\\RolesTable',
  'backend.users-table' => 'App\\Http\\Livewire\\Backend\\UsersTable',
  'frontend.two-factor-authentication' => 'App\\Http\\Livewire\\Frontend\\TwoFactorAuthentication',
);