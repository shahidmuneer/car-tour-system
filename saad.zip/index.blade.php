<!-- Mirrored from exoticsracing.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Aug 2022 09:06:56 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<!-- /Added by HTTrack -->

@include('template.head')
@include('template.navbar')


<body onclick="void(0)" class="et_bloom homepage" onload="_googWcmGet(phoneCallback, '+1 (702) 800-0521')">
    <script type="text/javascript"></script>
    <!-- End Google Tag Manager (noscript) -->




    <main>
        <div class="w-carousel">
            <div id="slider" class="b-carousel owl-carousel ">
                <!-- DATA Item code page-slider-homepage -->
                <div class="item">
                    <div class="w-video__slide embed-responsive embed-responsive-16by9" data-youtube-id="2N_PCsUDxdA"
                        data-youtube-mute="1" data-youtube-autoplay="1" data-youtube-volume="0"></div>
                </div>
                <div class="item"><img style="height:670px;" src="{{ asset('images/landingpage/slide1.png') }}"
                        alt="New Location" width="1800" height="700" /></div>
                <div class="item">
                    <img class="block" style="height:670px;"
                        src="https://images.unsplash.com/photo-1621431057082-56fc8f3d49c4?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80" />
                    <div class="w-caption bottom-left">
                        <div class="caption">
                            <div class="head"><strong>THE FASTEST AND MOST ENJOYABLE CIRCUIT IN LAS
                                    VEGAS</strong></div>
                            <!--head-->The Exotics Racing racetrack was specifically designed for supercars with a
                            variety of turns, safety features, and the fastest straight away.
                        </div>
                        <a class="b-btn__bone" href="las-vegas-supercar-driving-experience.html"> <span
                                class="text">SUPERCAR DRIVING EXPERIENCE</span> <span
                                class="icon"><span></span></span> <span class="icon2"></span> </a>
                    </div>
                    <!--caption-->
                </div>
                <div class="item">
                    <img class="block" style="height:600px;" src="{{ asset('images/landingpage/slide2.jpg') }}"
                        alt="Happy Customers" />
                    <div class="w-caption bottom-left">
                        <div class="caption">
                            <div class="head">
                                <strong>
                                    VOTED #1 DRIVING EXPERIENCE <br />BY OUR 260,000
                                    <g class="gr_ gr_41 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace"
                                        id="41" data-gr-id="41">CUSTOMERS </g>
                                </strong>
                            </div>
                            <!--head-->
                            <g class="gr_ gr_41 gr-alert gr_spell gr_inline_cards gr_disable_anim_appear ContextualSpelling ins-del multiReplace"
                                id="41" data-gr-id="41">As </g>
                            a multi-award-winning attraction, we&rsquo;ve earned kudos from our 260,000+ satisfied
                            clients who have enjoyed our world-class
                            <g class="gr_ gr_40 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del"
                                id="40" data-gr-id="40">super car </g>
                            driving experience at our two exclusive tracks.
                        </div>
                        <a class="b-btn__bone" href="reviews.html"> <span class="text">customer reviews</span>
                            <span class="icon"><span></span></span> <span class="icon2"></span> </a>
                    </div>
                </div>
                <div class="item">
                    <img style="height:600px;" src="{{ asset('images/landingpage/slide3.jpg') }}" alt="Celebrities" />
                    <div class="w-caption bottom-right" style="bottom: 7%; right: 6%;"><a class="b-btn__bone"
                            href="vegas-superkarts-outdoor-go-kart.html"> <span class="text">GO-KART</span>
                            <span class="icon"><span></span></span> <span class="icon2"></span> </a></div>
                </div>
                <div class="item">
                    <img style="height:600px;"
                        src="https://images.unsplash.com/photo-1526550517342-e086b387edda?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1229&q=80"
                        alt="Celebrities" />
                    <div class="w-caption center">
                        <div class="caption">
                            <div class="head"><strong>CELEBRITY CONNECTION</strong></div>
                            You never know who you will see at Exotics Racing! From Lebron James to Zac Efron,
                            compare your lap-time with many celebrities, including Formula One drivers, who are
                            ranked in the Exotics Racing Time Trial Challenge and see if you are faster than them on
                            our racetrack!
                        </div>
                        <a class="b-btn__bone" href="https://exoticsracing.com:443/galleries/hall-of-fame"> <span
                                class="text">hall of fame</span> <span class="icon"><span></span></span> <span
                                class="icon2"></span> </a>
                    </div>
                    <!--caption-->
                </div>
                <!--<div class="item"><img src="https://d1i1eo6qmdfmdv.cloudfront.net/upload/Slider-1800x700-Homepage-HPDE.jpg" alt="Racing School and HPDE" class="poster block"  />
                    <div class="w-caption bottom-right">
                    <table class="text-center">
                    <tbody>
                    <tr>
                    <td><img src="https://d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/30.png" alt="" />
                    <div class="text">1-Day Porsche HPDE | $1,990</div>
                    <a class="blue-button" href="/experience/booking/create/gift_package_id/24">BOOK NOW</a></td>
                    </tr>
                    </tbody>
                    </table>
                    </div>
                    </div>-->
            </div>
            <!--
                  <div class="overlay"></div>
                  <div class="car-selection-head">
                      <ul>
                                      <li data-id="65">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/porsche_cayman_gts/Cayman-718-listview.png">
                                  </a>
                              </li>
                                      <li data-id="141">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/porsche_cayman_gt4/PORSCHE_CAYMAN_GT4_listview1.png">
                                  </a>
                              </li>
                                      <li data-id="14">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/15.png">
                                  </a>
                              </li>
                                      <li data-id="15">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/aston_martin_vantage_s/vantage-gt-listview.png">
                                  </a>
                              </li>
                                      <li data-id="66">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/corvette_c8/new/corvettec8-listview.png">
                                  </a>
                              </li>
                                      <li data-id="4">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/1.png">
                                  </a>
                              </li>
                                      <li data-id="107">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/mercedes_amg_gtr/Mercedes-AMG-GTR-listview.png">
                                  </a>
                              </li>
                                      <li data-id="7">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/4.png">
                                  </a>
                              </li>
                                      <li data-id="88">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/109.png">
                                  </a>
                              </li>
                                      <li data-id="129">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/shelby-gt500/gt500_listview.png">
                                  </a>
                              </li>
                                      <li data-id="101">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/audi_r8_v10_plus/R8V10Plus-listview.png">
                                  </a>
                              </li>
                                      <li data-id="126">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/porsche_992_gt3/992_GT3_listview.png">
                                  </a>
                              </li>
                                      <li data-id="60">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/lamborghini_huracan_lp610/huracan-listview.png">
                                  </a>
                              </li>
                                      <li data-id="83">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/porsche_911_gt3_rs/porsche-gt3rs_listing.png">
                                  </a>
                              </li>
                                      <li data-id="11">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/107.png">
                                  </a>
                              </li>
                                      <li data-id="78">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/106.png">
                                  </a>
                              </li>
                                      <li data-id="127">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/ferrari_488_pista/ferrari-488-pista-listview.png">
                                  </a>
                              </li>
                                      <li data-id="132">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/lamborghini_huracan_sto/huracan_sto_listview.png">
                                  </a>
                              </li>
                                      <li data-id="125">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/porsche_gt2_rs/GT2RS-listview.png">
                                  </a>
                              </li>
                                      <li data-id="153">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/mclaren_570gt4/EXR_MCLAREN_NEW_570_GT4_CUTOUT_list.png">
                                  </a>
                              </li>
                                      <li data-id="157">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/ferrari_488_challenge_evo/FERRARI_488_CHALLENGE_listview.png">
                                  </a>
                              </li>
                                      <li data-id="166">
                                  <a href="javascript:void(0);">
                                      <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/lamborghini_supertrofeo/Super-Trofeo-EVO_listview.png">
                                  </a>
                              </li>
                              </ul>
                      <div id="car-place" class="w-product__stats"></div>
                  </div> -->
        </div>
        <section class="w-experiences">
            <div class="b-experience__search" style="background:black;">
                <form class="" data-ajax="false" id="inlineForm"
                    action="https://exoticsracing.com/driving-experience/search" method="GET">
                    <div class="w-select track">
                        <select class="b-select" name="SearchBoxForm[track]" id="SearchBoxForm_track">
                            <option value="">CHOOSE YOUR EXPERIENCE</option>
                            <option value="1">Exotics Racing Supercar Racetrack</option>
                            <option value="153">Vegas Superkarts Go-Kart Track</option>
                            <option value="158">Vegas Off-Road Experience Dirt Track</option>
                        </select>
                        <i class="icon icon-angle-down"></i>
                    </div>
                    <div class="w-select car">
                        <select class="b-select" name="SearchBoxForm[category]" id="SearchBoxForm_category">
                            <option value="">CHOOSE YOUR VEHICLE</option>
                            <option value="22">Drive a Go-Kart</option>
                            <option value="3">Drive a Ferrari</option>
                            <option value="4">Drive a Lamborghini</option>
                            <option value="5">Drive a Porsche</option>
                            <option value="6">Drive a McLaren</option>
                            <option value="7">Drive an Audi R8</option>
                            <option value="8">Drive a Nissan GT-R</option>
                            <option value="39">$699 / 5 laps</option>
                            <option value="11">Drive a Corvette</option>
                            <option value="10">Drive a Mercedes-Benz</option>
                            <option value="25">Drive an Off-Road Baja Truck</option>
                            <option value="23">Drive a Mustang</option>
                            <option value="17">Drifting Ride-Along</option>
                            <option value="2">Ride-Along Experience</option>
                            <option value="16">Supercar Ride-Along</option>
                        </select>
                        <i class="icon icon-angle-down"></i>
                    </div>
                    <div class="w-select date">
                        <input class="b-select" placeholder="Select Date" type="text" autocomplete="off"
                            name="SearchBoxForm[date]" id="SearchBoxForm_date" />
                        <script>
                            $('#SearchBoxForm_date').bexdatepicker({
                                'autoclose': true,
                                'startDate': '1d',
                                'checkAvailableDates': true,
                                'availableDates': [],
                                'language': 'en',
                                'format': 'mm\x2Fdd\x2Fyyyy',
                                'weekStart': 0
                            })
                        </script> <i class="icon icon-calendar"></i>
                    </div>
                    <div class="w-btn__search">
                        <button class="b-btn__book search styled block" style="background:red;" type="submit">
                            <span class="text">search</span>
                        </button>
                    </div>
                    <!--w-btn__search-->
                </form>
            </div>
            <section class="w-section" style="padding-top: 20px;">
                <!-- DATA Item code page-block-homepage-header -->
                <div class="top-section-head">
                    <p></p>
                    <h1>DRIVE SUPERCARS TO THE LIMIT<br />ON THE FASTEST&nbsp;&amp; SAFEST RACETRACK IN LAS VEGAS
                    </h1>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has
                        been the industry's standard <br> dummy text ever since the 1500s, when an unknown printer
                        took a galley of type and scrambled it to make a type specimen book..</p>
                </div>
            </section>
            <!-- DATA Item code page-block-homepage-vip-group-events -->
            <section class="w-promo">
                <div class="elementor-element elementor-element-abdf560 elementor-cta--skin-cover elementor-cta--valign-top elementor-animated-content elementor-bg-transform elementor-bg-transform-zoom-in elementor-widget elementor-widget-call-to-action"
                    data-id="abdf560" data-element_type="widget" data-widget_type="call-to-action.default">
                    <div class="elementor-widget-container">
                        <a class="elementor-cta" href="/supercar-tour-days">
                            <div class="elementor-cta__bg-wrapper">
                                <div class="elementor-cta__bg elementor-bg"
                                    style="background-image: url(https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercars-233-600x500-overlay.jpg);">
                                </div>
                                <div class="elementor-cta__bg-overlay"></div>
                            </div>
                            <div class="elementor-cta__content">

                                <h2
                                    class="elementor-cta__title elementor-cta__content-item elementor-content-item elementor-animated-item--grow">
                                    Tour Days</h2>

                            </div>
                            <div class="elementor-ribbon elementor-ribbon-right">
                                <div class="elementor-ribbon-inner">Open road</div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="conta.iner">
                    <div class="row ">
                        <div class="col-md-3">
                            <div
                                class="card"style="background-image: url('{{ asset('img/supercar1.jpg') }}');
                            background-position: center center;
                            background-repeat: no-repeat;
                            background-size:cover;
                            width:100%;
                        }">

                                <div class="card-body">
                                    <style>
                                        .elementor-ribbon-inner {
                                            background-color: #ff0000;
                                            color: white;
                                            /* margin-top: 45px; */
                                            transform: translateY(-50%) translateX(-50%) translateX(45px) rotate(-45deg);
                                            font-family: "Arial", Sans-serif;
                                            font-size: 12px;
                                            font-weight: 500;
                                            text-transform: uppercase;
                                        }

                                        .elementor-ribbon.elementor-ribbon-right {
                                            -webkit-transform: rotate(90deg);
                                            -ms-transform: rotate(90deg);
                                            transform: rotate(90deg);
                                            left: auto;
                                            right: 0;
                                        }
                                    </style>
                                    {{-- <div class="elementor-ribbon elementor-ribbon-right">
                                        <div class="elementor-ribbon-inner cssinspector-current-outline">Private Track
                                        </div>
                                    </div>
                                    <h5 class="card-title mt-5 mb-5">TRACK DAYS</h5>
                                </div> --}}
                                </div>



                            </div>
                            <div class="col-md-3">
                                <div
                                    class="card"style="background-image: url('{{ asset('img/supercar2.jpg') }}');
                            background-position: center center;
                            background-repeat: no-repeat;
                            background-size:cover;
                        }">

                                    <div class="card-body">
                                        <h5 class="card-title mt-5 mb-5">TOUR DAYS</h5>
                                    </div>
                                </div>


                            </div>
                            <div class="col-md-3">
                                <div
                                    class="card"style="background-image: url('{{ asset('img/supercar3.webp') }}');
                            background-position: center center;
                            background-repeat: no-repeat;
                            background-size:cover;
                        }">

                                    <div class="card-body">
                                        <h5 class="card-title mt-5 mb-5">RENTALS</h5>
                                    </div>
                                </div>


                            </div>

                            <div class="col-md-3">
                                <div
                                    class="card"style="background-image: url('{{ asset('img/supercar4.jpg') }}');
                            background-position: center center;
                            background-repeat: no-repeat;
                            background-size:cover;
                        }">

                                    <div class="card-body">
                                        <h5 class="card-title mt-5 mb-5">TEST DRIVE</h5>
                                    </div>
                                </div>


                            </div>


                        </div>
                        {{-- <div class="item">
                        <div style="background-image: url('{{ asset('images/landingpage/img6.jpg') }}');"
                            class="img-responsive"></div>
                        <div class="overlay">
                            <div class="b-promo-content">
                                <h3 class="title">SUPERCAR DRIVING EXPERIENCES<br />LAS VEGAS RACETRACK</h3>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                    Ipsum has been the industry's standard dummy text ever since the 1500s, when an
                                    unknown printer took a galley of type and scrambled it to make a type specimen
                                    book.</p>
                                <br />
                                <div style="text-align: center;"><a href="las-vegas-supercar-driving-experience.html"
                                        class="btn">LEARN
                                        MORE</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div style="background-image: url('{{ asset('images/landingpage/img5.jpg') }}');"
                            class="img-responsive"></div>
                        <div class="overlay">
                            <div class="b-promo-content">
                                <h3 class="title">GROUPS</h3>
                                <p><b>GROUPS</b><br />Exotics Racing provides groups a unique venue to host a
                                    top-level event for your corporate or personal guests. Our dedicated team is at
                                    your disposal to help you build an incomparable event.</p>
                                <br />
                                <div style="text-align: center;"><a href="las-vegas-bachelor-party.html"
                                        class="btn btn">groups</a></div>
                                <div style="text-align: center;"><a href="group-corporate-events.html"
                                        class="btn-invert">corporate events</a></div>
                                <br />
                                <h3 class="title">VIP EXPERIENCES</h3>
                                <p><b>VIP EXPERIENCES</b><br />From the VIP Concierge Service and private business
                                    lounge access to dedicated one-on-one coaching, personalize your unforgettable
                                    VIP experience with us.</p>
                                <br />
                                <div style="text-align: center;"><a href="driving-experience/vip-experience-2.html"
                                        class="btn">learn
                                        more</a></div>
                                <br />
                                <h3 class="title">GIFT PACKAGES</h3>
                                <p><b>GIFT PACKAGES</b><br />An Exotics Racing driving experience is the most
                                    exhilarating gift for any occasion. With our all-inclusive pricing, select a
                                    pre-built gift package or specify your own dollar amount and offer the gift of a
                                    lifetime!</p>
                                <br />
                                <div style="text-align: center;"><a href="driving-experience/gift-ideas.html"
                                        class="btn">learn more</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div style="background-image: url('{{ asset('images/landingpage/img2.jpg') }}');"
                            class="img-responsive"></div>
                        <div class="overlay">
                            <div class="b-promo-content">
                                <h3 class="title">
                                    <g class="gr_ gr_34 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace"
                                        id="34" data-gr-id="34">GO-KART<br />LAS VEGAS</g>
                                </h3>
                                <p>Race against your friends with the best go-kart equipment at VEGAS SUPERKARTS!
                                    Our brand-new outdoor racetrack ensures high safety and fun for anyone racing
                                    with us. There is no other place in Las Vegas where you can find what we offer,
                                    so if you want to race the best go karts, come race with us!</p>
                                <br />
                                <div style="text-align: center;"><a href="vegas-superkarts-outdoor-go-kart.html"
                                        class="btn">learn more</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div style="background-image: url('{{ asset('images/landingpage/img3.jpg') }}');"
                            class="img-responsive"></div>
                        <div class="overlay">
                            <div class="b-promo-content">
                                <h3 class="title">Off Road<br />VEGAS OFF-ROAD</h3>
                                <p>Experience the thrill of driving a FORD Race Truck on our 1 mile off-road track.
                                    Defy gravity on eight jumps that will launch you up to 10 feet into the air.</p>
                                <br />
                                <div style="text-align: center;"><a href="driving-experience-off-road.html"
                                        class="btn">Learn More</a></div>
                            </div>
                        </div>
                    </div> --}}
                    </div>
            </section>
            <section class="w-supercar">
                <!-- DATA Item code page-caption-main -->
                <div class="section-head" style="background:black;">
                    <h2>RACETRACK SUPERCAR DRIVING EXPERIENCES</h2>
                    <p><span>Our supercars are your supercars! Pick your favorite exotics&nbsp;from the largest
                            fleet in the world and drive them without any speed limits.</span></p>
                </div>
                <div id="experiences-packages-index">
                    <div class="container">
                        <div class="grid-d-3 grid-tl-4 grid-t-6 grid-m-12">
                            <div class="b-supercar">
                                <div class="over-wraper">
                                    <form action="https://exoticsracing.com/driving-experience" method="post"
                                        class="b-specs-rm">
                                        <div class="b-supercar__item">
                                            <a href="driving-experience/drive-ferrari.html" class="block">
                                                <figure class="text-center">
                                                    <div class="b-supercar__item__image-wrapper">
                                                        <img class="lazy b-supercar__item__image"
                                                            data-original="https://d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/ferrari_f8/ferrarif8-listview.png"
                                                            src="images/img-loader.gif" alt="" />
                                                    </div>
                                                    <figcaption class="caption">
                                                        Drive a <span class="bold-grey">Ferrari</span>
                                                    </figcaption>
                                                    <p class="price text-center">
                                                        from $299 / 5 LAPS
                                                    </p>
                                                </figure>
                                            </a>
                                            <div class="controls">
                                                <p class="price text-center">
                                                    from $45 per lap
                                                </p>
                                                <ul class="b-ferrari__list unstyled-list">
                                                    <li class="inactive">
                                                        <a href="driving-experience/drive-ferrari.html">
                                                            <b>
                                                                Compare all Ferraris </b>
                                                        </a>
                                                    </li>
                                                    <input type="hidden" name="model_id" id="package_id"
                                                        value="1">
                                                    <li>
                                                        <a class="block"
                                                            href="driving-experience/ferrari-f430-f1.html">
                                                            Ferrari F430 F1 <i class="fa fa-angle-right"></i>
                                                        </a>
                                                    </li>
                                                    <input type="hidden" name="model_id" id="package_id"
                                                        value="106">
                                                    <li>
                                                        <a class="block"
                                                            href="driving-experience/ferrari-488-gtb.html">
                                                            Ferrari 488 GTB <i class="fa fa-angle-right"></i>
                                                        </a>
                                                    </li>
                                                    <input type="hidden" name="model_id" id="package_id"
                                                        value="127">
                                                    <li>
                                                        <a class="block"
                                                            href="driving-experience/ferrari-488-pista.html">
                                                            Ferrari 488 Pista <i class="fa fa-angle-right"></i>
                                                        </a>
                                                    </li>
                                                    <input type="hidden" name="model_id" id="package_id"
                                                        value="143">
                                                    <li>
                                                        <a class="block"
                                                            href="driving-experience/ferrari-488-challenge-evo.html">
                                                            Ferrari 488 Challenge Evo <i class="fa fa-angle-right"></i>
                                                        </a>
                                                    </li>
                                                </ul>
                                                <div class="w-btn">
                                                    <div class="container">
                                                        <div class="grid-d-12 grid-m-12">
                                                            <a class="inverblue-button"
                                                                href="driving-experience/drive-ferrari.html">
                                                                LEARN MORE </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <input id="track_id" type="hidden" value="1" name="track_id">
                                    </form>
                                </div>
                            </div>
                            <div class="custom-shadow"></div>
                        </div>
                        <div class="grid-d-3 grid-tl-4 grid-t-6 grid-m-12">
                            <div class="b-supercar">
                                <div class="over-wraper">
                                    <form action="https://exoticsracing.com/driving-experience" method="post"
                                        class="b-specs-rm">
                                        <div class="b-supercar__item">
                                            <a href="driving-experience/drive-lamborghini.html" class="block">
                                                <figure class="text-center">
                                                    <div class="b-supercar__item__image-wrapper">
                                                        <img class="lazy b-supercar__item__image"
                                                            data-original="https://d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/31.png"
                                                            src="images/img-loader.gif" alt="" />
                                                    </div>
                                                    <figcaption class="caption">
                                                        Drive a <span class="bold-grey">Lamborghini</span>
                                                    </figcaption>
                                                    <p class="price text-center">
                                                        from $299 / 5 LAPS
                                                    </p>
                                                </figure>
                                            </a>
                                            <div class="controls">
                                                <p class="price text-center">
                                                    from $45 per lap
                                                </p>
                                                <ul class="b-ferrari__list unstyled-list">
                                                    <li class="inactive">
                                                        <a href="driving-experience/drive-lamborghini.html">
                                                            <b>
                                                                Compare all Lamborghinis </b>
                                                        </a>
                                                    </li>
                                                    <input type="hidden" name="model_id" id="package_id"
                                                        value="4">
                                                    <li>
                                                        <a class="block"
                                                            href="driving-experience/lamborghini-gallardo-lp550.html">
                                                            Lamborghini Gallardo LP550-2 <i
                                                                class="fa fa-angle-right"></i>
                                                        </a>
                                                    </li>
                                                    <input type="hidden" name="model_id" id="package_id"
                                                        value="31">
                                                    <li>
                                                        <a class="block"
                                                            href="driving-experience/lamborghini-huracan-lp580-2.html">
                                                            Lamborghini Huracan LP580-2 <i
                                                                class="fa fa-angle-right"></i>
                                                        </a>
                                                    </li>
                                                    <input type="hidden" name="model_id" id="package_id"
                                                        value="132">
                                                    <li>
                                                        <a class="block"
                                                            href="driving-experience/lamborghini-huracan-sto.html">
                                                            Lamborghini Huracan STO <i class="fa fa-angle-right"></i>
                                                        </a>
                                                    </li>
                                                    <input type="hidden" name="model_id" id="package_id"
                                                        value="145">
                                                    <li>
                                                        <a class="block"
                                                            href="driving-experience/lamborghini-super-trofeo-evo.html">
                                                            Lamborghini Huracan Super Trofeo Evo <i
                                                                class="fa fa-angle-right"></i>
                                                        </a>
                                                    </li>
                                                </ul>
                                                <div class="w-btn">
                                                    <div class="container">
                                                        <div class="grid-d-12 grid-m-12">
                                                            <a class="inverblue-button"
                                                                href="driving-experience/drive-lamborghini.html">
                                                                LEARN MORE </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <input id="track_id" type="hidden" value="1" name="track_id">
                                    </form>
                                </div>
                            </div>
                            <div class="custom-shadow"></div>
                        </div>
                        <div class="grid-d-3 grid-tl-4 grid-t-6 grid-m-12">
                            <div class="b-supercar">
                                <div class="over-wraper">
                                    <form action="https://exoticsracing.com/driving-experience" method="post"
                                        class="b-specs-rm">
                                        <div class="b-supercar__item">
                                            <a href="driving-experience/drive-porsche.html" class="block">
                                                <figure class="text-center">
                                                    <div class="b-supercar__item__image-wrapper">
                                                        <img class="lazy b-supercar__item__image"
                                                            data-original="https://d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/porsche_992_gt3/992_GT3_listview.png"
                                                            src="images/img-loader.gif" alt="" />
                                                    </div>
                                                    <figcaption class="caption">
                                                        Drive a <span class="bold-grey">Porsche</span>
                                                    </figcaption>
                                                    <p class="price text-center">
                                                        from $199 / 5 LAPS
                                                    </p>
                                                </figure>
                                            </a>
                                            <div class="controls">
                                                <p class="price text-center">
                                                    from $28 per lap
                                                </p>
                                                <ul class="b-ferrari__list unstyled-list">
                                                    <li class="inactive">
                                                        <a href="driving-experience/drive-porsche.html">
                                                            <b>
                                                                Compare all Porsches </b>
                                                        </a>
                                                    </li>
                                                    <input type="hidden" name="model_id" id="package_id"
                                                        value="102">
                                                    <li>
                                                        <a class="block"
                                                            href="driving-experience/porsche-cayman-gts.html">
                                                            Porsche 718 Cayman GTS <i class="fa fa-angle-right"></i>
                                                        </a>
                                                    </li>
                                                    <input type="hidden" name="model_id" id="package_id"
                                                        value="140">
                                                    <li>
                                                        <a class="block"
                                                            href="driving-experience/porsche-cayman-gt4.html">
                                                            Porsche 718 Cayman GT4 <i class="fa fa-angle-right"></i>
                                                        </a>
                                                    </li>
                                                    <input type="hidden" name="model_id" id="package_id"
                                                        value="126">
                                                    <li>
                                                        <a class="block"
                                                            href="driving-experience/porsche-992-gt3.html">
                                                            Porsche 992 GT3 <i class="fa fa-angle-right"></i>
                                                        </a>
                                                    </li>
                                                    <input type="hidden" name="model_id" id="package_id"
                                                        value="125">
                                                    <li>
                                                        <a class="block"
                                                            href="driving-experience/porsche-gt2-rs.html">
                                                            Porsche 991 GT2 RS <i class="fa fa-angle-right"></i>
                                                        </a>
                                                    </li>
                                                    <input type="hidden" name="model_id" id="package_id"
                                                        value="95">
                                                    <li>
                                                        <a class="block"
                                                            href="driving-experience/porsche-911-gt3-rs-gen1.html">
                                                            Porsche 991 GT3 RS <i class="fa fa-angle-right"></i>
                                                        </a>
                                                    </li>
                                                </ul>
                                                <div class="w-btn">
                                                    <div class="container">
                                                        <div class="grid-d-12 grid-m-12">
                                                            <a class="inverblue-button"
                                                                href="driving-experience/drive-porsche.html">
                                                                LEARN MORE </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <input id="track_id" type="hidden" value="1" name="track_id">
                                    </form>
                                </div>
                            </div>
                            <div class="custom-shadow"></div>
                        </div>
                    </div>
                    <div class="w-more__cars">
                        <div class="b-header__sub">
                            <h2 class="b-header__sub-txt">
                                Is one not <b>enough?</b>
                            </h2>
                        </div>
                        <div class="container">
                            <div class="text-center">
                                <figure class="b-more__cars">
                                    <a href="driving-experience/combos.html">
                                        <img class="lazy" src="themes/exotics/images/no-image.png"
                                            data-original="/themes/wp_exr/img/car_md/img11.png" alt="">
                                    </a>
                                    <figcaption>
                                        Create your own multi-car package to drive up to 19 supercars and receive
                                        <strong>up to $100 off each additional car.</strong> <br>
                                        <br>
                                        <a class="inverblue-button" href="driving-experience/combos.html">
                                            MULTIPLE CAR PACKAGES </a>
                                        <a class="blue-button" href="driving-experience.html">
                                            CUSTOMIZED EXPERIENCE </a>
                                    </figcaption>
                                </figure>
                                <!--b-more__cars-->
                            </div>
                        </div>
                    </div>
                    <!--w-more__cars-->
                    <br>
                    <br>
                </div>
            </section>
            <!-- DATA Item code page-block-homepage-driving-experience -->
            <section class="w-section design-narrow">
                <div class="section-head" style="background:black;">
                    <h2><strong>The #1 supercar</strong> driving experience</h2>
                    <p>Why choose Exotic Racing, the best driving experience in America?</p>
                </div>
                <div class="container">
                    <div class="swiper-box swiper3">
                        <div class="swiper-container driving-experience-swiper">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div>
                                        <div class="img ico1"></div>
                                        <b>Largest Fleet of<br />Supercars in the World</b>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting
                                            industry. Lorem Ipsum has been the industry's standard dummy text ever
                                            since the 1500s, when an unknown printer took a galley of type and
                                            scrambled it to make a type specimen book.</p>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div>
                                        <div class="img ico2"></div>
                                        <b>Fastest and Safest<br />Racetrack</b>
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting
                                            industry. Lorem Ipsum has been the industry's standard dummy text ever
                                            since the 1500s, when an unknown printer took a galley of type and
                                            scrambled it to make a type specimen book.</p>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div>
                                        <div class="img ico3"></div>
                                        <b>The Original Supercar<br />Driving Experience</b>
                                        <p>In 2005, we created the world&rsquo;s first&nbsp;supercar driving
                                            experience in Europe. Since then, Exotics Racing has become the number
                                            1&nbsp;driving experience worldwide. Many have tried to copy us, but we
                                            remain the leader of the pack. Don&rsquo;t settle for less, drive the
                                            original.</p>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div>
                                        <div class="img ico5"></div>
                                        <b>300,000+<br />Satisfied Clients</b>
                                        <p>
                                            Among our competition, we are the most highly rated supercar driving
                                            experience. Our commitment to
                                            <g class="gr_ gr_50 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace"
                                                id="50" data-gr-id="50">high quality</g>
                                            service, fun and safety
                                            <g class="gr_ gr_49 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace"
                                                id="49" data-gr-id="49">is</g>
                                            unparalleled. As a result, we&rsquo;ve won multiple Best of Las Vegas
                                            and TripAdvisor awards over the past several years.
                                        </p>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div>
                                        <div class="img ico6"></div>
                                        <b>Celebrity<br />Connection</b>
                                        <p>There is a reason why Lebron James, Michelle Rodriguez, Mario Andretti,
                                            Kyle Busch, DJ Tiesto, Jay Leno, Eli Tomac, Chuck Liddell, Caitlyn
                                            Jenner, and many more choose us as their destination of choice: there is
                                            nothing like Exotics racing!</p>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div>
                                        <div class="img ico8"></div>
                                        <b>EXOTICS RACING <br />TIME TRIAL CHALLENGE</b>
                                        <p>Take part of the world's largest motorsports competition, exclusively at
                                            Exotics Racing Las Vegas. Whether you want to race against the clock or
                                            a friend, our automatic live and online ranking allows you to compare
                                            your times and rank against other drivers.</p>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div>
                                        <div class="img ico8"></div>
                                        <b>Friendly<br />Experts</b>
                                        <p>Overseen by a team of friendly racing experts, we have the best racing
                                            instructors and racecar drivers who deliver an unrivaled driving
                                            experience in the United States of America.</p>
                                    </div>
                                </div>
                                <div class="swiper-slide">
                                    <div>
                                        <div class="img ico7"></div>
                                        <b>Motorsport<br />Destinations</b>
                                        <p>Our exclusive racetrack is located at Speed Vegas. There&nbsp;are also
                                            the fastest go-kart track &amp; Off-Road track in Las Vegas opened 7
                                            days a week.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                </div>
            </section>
            <!-- DATA Item code page-block-homepage-galleries -->
            <section class="w-gallery main">
                {{-- <div class="container">
                    <div class="b-gallery text-center">
                        <div class="b-header">
                            <h2 class="b-header__txt">gallerieS &amp; CELEBRITIES</h2>
                        </div>
                        <div class="w-text">Lorem Ipsum is simply dummy text of the printing and typesetting
                            industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
                            when an unknown printer took a galley of type and scrambled it to make a type specimen
                            book.</div>
                        <div class="w-btn"><a class="btn-inver-white"
                                href="media/tab/hall-of-fame.html">celebrities</a> <a class="btn-inver-white"
                                href="media/tab/photos.html">photos</a> <a class="btn-inver-white"
                                href="media/tab/videos.html">videos</a><a class="btn-inver-white"
                                href="media.html">media</a></div>
                    </div>
                </div> --}}

                {{-- <div class="elementor-row">
                    <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-45e8e11"
                        data-id="45e8e11" data-element_type="column">
                        <div class="elementor-column-wrap elementor-element-populated">
                            <div class="elementor-widget-wrap">
                                <div class="elementor-element elementor-element-7d7572d1 elementor-widget elementor-widget-image"
                                    data-id="7d7572d1" data-element_type="widget" data-widget_type="image.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-image">
                                            <img width="600" height="500" alt="Supercars on track"
                                                data-srcset="https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercar-227-600x500-1.jpg 600w, https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercar-227-600x500-1-300x250.jpg 300w"
                                                data-src="https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercar-227-600x500-1.jpg"
                                                data-sizes="(max-width: 600px) 100vw, 600px"
                                                class="attachment-large size-large lazyloaded"
                                                src="https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercar-227-600x500-1.jpg"
                                                sizes="(max-width: 600px) 100vw, 600px"
                                                srcset="https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercar-227-600x500-1.jpg 600w, https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercar-227-600x500-1-300x250.jpg 300w"><noscript><img
                                                    width="600" height="500"
                                                    src="https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercar-227-600x500-1.jpg"
                                                    class="attachment-large size-large" alt="Supercars on track"
                                                    srcset="https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercar-227-600x500-1.jpg 600w, https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercar-227-600x500-1-300x250.jpg 300w"
                                                    sizes="(max-width: 600px) 100vw, 600px" /></noscript>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-24399603"
                        data-id="24399603" data-element_type="column">
                        <div class="elementor-column-wrap elementor-element-populated">
                            <div class="elementor-widget-wrap">
                                <div class="elementor-element elementor-element-14e4c40 elementor-widget elementor-widget-heading"
                                    data-id="14e4c40" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">TRACK DAYS</h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-649ce75 elementor-widget elementor-widget-text-editor"
                                    data-id="649ce75" data-element_type="widget"
                                    data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-text-editor elementor-clearfix">
                                            <p>You’ll never look at Go-carts the same again. Driving today’s best
                                                Supercars around a professional sports track is something you need to
                                                experience.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-d18cb63 elementor-widget elementor-widget-toggle"
                                    data-id="d18cb63" data-element_type="widget" data-widget_type="toggle.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-toggle" role="tablist">
                                            <div class="elementor-toggle-item">
                                                <div id="elementor-tab-title-2191" class="elementor-tab-title"
                                                    data-tab="1" role="tab"
                                                    aria-controls="elementor-tab-content-2191" aria-expanded="false">
                                                    <span class="elementor-toggle-icon elementor-toggle-icon-left"
                                                        aria-hidden="true">
                                                        <span class="elementor-toggle-icon-closed"><i
                                                                class="fas fa-caret-right"></i></span>
                                                        <span class="elementor-toggle-icon-opened"><i
                                                                class="elementor-toggle-icon-opened fas fa-caret-up"></i></span>
                                                    </span>
                                                    <a href="" class="elementor-toggle-title">Read More</a>
                                                </div>

                                                <div id="elementor-tab-content-2191"
                                                    class="elementor-tab-content elementor-clearfix" data-tab="1"
                                                    role="tabpanel" aria-labelledby="elementor-tab-title-2191">
                                                    <p>Track Days are the most exhilarating and heart-pumping experience
                                                        we offer. Our customers, (under the careful eyes of our driving
                                                        coaches) can push our exotic and performance cars to their
                                                        limits.</p>
                                                    <p>We host our track days at Canadian Tire Motorsport Park in
                                                        Bowmanville and Grand Bend Raceway in Grand Bend. Both tracks
                                                        are very different from one another. Canadian Tire Motorsport
                                                        Parks DDT (Driver Development Track) is very technical with 20+
                                                        turns. This track is used by professionals to train and is
                                                        challenging but very rewarding as you feel the rush of the
                                                        handling, brakes, and power of these mighty machines. Grand Bend
                                                        raceway has far fewer turns, but longer straits, where you can
                                                        get the cars up to higher speeds.</p>
                                                    <p>No matter the track, you will have an experience of a lifetime.
                                                    </p>
                                                    <p>Join us at Canadian Tire Motorsport Park or Grand Bend Raceway
                                                        for an adrenaline-filled day. Step into the seat of some of the
                                                        fastest production vehicles ever made and strap yourself in.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> --}}

                <div class="row m-0 " style="">
                    <div class="col-lg-6 col-md-6 ">

                        <img width="100%" height="" alt="Supercars on track"
                            src="{{ asset('img/Supercar-227-600x500-1.jpg') }}"> <img src="" alt="">
                    </div>
                    <div class="col-lg-6 col-md-6  ">
                        <div
                            class="mt-5 mb-5"style="background-image: url('{{ asset('img/Socials.png') }}');
                        background-position: center center;
                        background-repeat: no-repeat;
                        background-size: 80% auto;
                    }">

                            <h2 class="text-white "
                                style="display: flex;
                            flex-wrap: nowrap;
                            justify-content: center;
                        ">
                                TRACK DAYS</h2>

                        </div>

                        <p class="mt-5" style="color :white">Track Days are the most exhilarating and heart-pumping
                            experience
                            we offer. Our customers, (under the careful eyes of our driving
                            coaches) can push our exotic and performance cars to their
                            limits.</p>


                        <p>
                            <a class="mt-3" data-toggle="collapse" href="#multiCollapseExample1" role="button"
                                aria-expanded="false" aria-controls="multiCollapseExample1">read more</a>
                        </p>
                        <div class="row ">
                            <div class="col">
                                <div class="collapse multi-collapse" id="multiCollapseExample1">
                                    <p style="color :white">We host our track days at Canadian Tire Motorsport Park in
                                        Bowmanville and Grand Bend Raceway in Grand Bend. Both tracks
                                        are very different from one another. Canadian Tire Motorsport
                                        Parks DDT (Driver Development Track) is very technical with 20+
                                        turns. This track is used by professionals to train and is
                                        challenging but very rewarding as you feel the rush of the
                                        handling, brakes, and power of these mighty machines. Grand Bend
                                        raceway has far fewer turns, but longer straits, where you can
                                        get the cars up to higher speeds.</p>
                                    <p style="color :white">No matter the track, you will have an experience of a
                                        lifetime.
                                    </p>
                                    <p style="color :white">Join us at Canadian Tire Motorsport Park or Grand Bend
                                        Raceway
                                        for an adrenaline-filled day. Step into the seat of some of the
                                        fastest production vehicles ever made and strap yourself in.</p>
                                </div>
                            </div>
                        </div>

                    </div>






                </div>

                <div class="row m-0 " style="">


                    <div class="col-lg-6 col-md-6  ">
                        <div
                            class="mt-5 mb-5"style="background-image: url('{{ asset('img/Socials.png') }}');
                        background-position: center center;
                        background-repeat: no-repeat;
                        background-size: 80% auto;
                    }">

                            <h2 class="text-white "
                                style="display: flex;
                            flex-wrap: nowrap;
                            justify-content: center;
                        ">
                                TOUR DAYS</h2>

                        </div>

                        <p class="mt-5" style="color :white">Are you keen to explore the Canadian roads in a
                            supercar? We offer driving tours out of our Oakville headquarters as you get a valuable
                            experience behind the wheel of an exotic car on quieter roadways.

                        </p>


                        <p>
                            <a class="mt-3" data-toggle="collapse" href="#multiCollapseExample1" role="button"
                                aria-expanded="false" aria-controls="multiCollapseExample1">read more</a>
                        </p>
                        <div class="row ">
                            <div class="col">
                                <div class="collapse multi-collapse" id="multiCollapseExample1">
                                    <p style="color :white">We host our track days at Canadian Tire Motorsport Park in
                                        Bowmanville and Grand Bend Raceway in Grand Bend. Both tracks
                                        are very different from one another. Canadian Tire Motorsport
                                        Parks DDT (Driver Development Track) is very technical with 20+
                                        turns. This track is used by professionals to train and is
                                        challenging but very rewarding as you feel the rush of the
                                        handling, brakes, and power of these mighty machines. Grand Bend
                                        raceway has far fewer turns, but longer straits, where you can
                                        get the cars up to higher speeds.</p>
                                    <p style="color :white">No matter the track, you will have an experience of a
                                        lifetime.
                                    </p>
                                    <p style="color :white">Join us at Canadian Tire Motorsport Park or Grand Bend
                                        Raceway
                                        for an adrenaline-filled day. Step into the seat of some of the
                                        fastest production vehicles ever made and strap yourself in.</p>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-lg-6 col-md-6 ">

                        <img width="100%" height="" alt="Supercars on track"
                            src="{{ asset('img/Supercar-227-600x500-1.jpg') }}"> <img src="" alt="">
                    </div>






                </div>
                <div class="row m-0 " style="">
                    <div class="col-lg-6 col-md-6 ">

                        <img width="100%" height="" alt="Supercars on track"
                            src="{{ asset('img/Supercar-227-600x500-1.jpg') }}"> <img src="" alt="">
                    </div>
                    <div class="col-lg-6 col-md-6  ">
                        <div
                            class="mt-5 mb-5"style="background-image: url('{{ asset('img/Socials.png') }}');
                        background-position: center center;
                        background-repeat: no-repeat;
                        background-size: 80% auto;
                    }">

                            <h2 class="text-white "
                                style="display: flex;
                            flex-wrap: nowrap;
                            justify-content: center;
                        ">
                                RENTALS</h2>

                        </div>

                        <p class="mt-5" style="color :white">Are you looking for an exotic car for rental, then
                            Supercar Experiences can be the ideal destination as we have the widest range of cars at
                            fair prices.

                        </p>


                        <p>
                            <a class="mt-3" data-toggle="collapse" href="#multiCollapseExample1" role="button"
                                aria-expanded="false" aria-controls="multiCollapseExample1">read more</a>
                        </p>
                        <div class="row ">
                            <div class="col">
                                <div class="collapse multi-collapse" id="multiCollapseExample1">
                                    <p style="color :white">We host our track days at Canadian Tire Motorsport Park in
                                        Bowmanville and Grand Bend Raceway in Grand Bend. Both tracks
                                        are very different from one another. Canadian Tire Motorsport
                                        Parks DDT (Driver Development Track) is very technical with 20+
                                        turns. This track is used by professionals to train and is
                                        challenging but very rewarding as you feel the rush of the
                                        handling, brakes, and power of these mighty machines. Grand Bend
                                        raceway has far fewer turns, but longer straits, where you can
                                        get the cars up to higher speeds.</p>
                                    <p style="color :white">No matter the track, you will have an experience of a
                                        lifetime.
                                    </p>
                                    <p style="color :white">Join us at Canadian Tire Motorsport Park or Grand Bend
                                        Raceway
                                        for an adrenaline-filled day. Step into the seat of some of the
                                        fastest production vehicles ever made and strap yourself in.</p>
                                </div>
                            </div>
                        </div>

                    </div>






                </div>
            </section>
            <!-- DATA Item code page-block-homepage-reviews -->
            <section class="w-reviews">
                <div class="section-head">
                    <h2>over <strong>260,000 happy customers</strong></h2>
                </div>
                <div class="b-review__slider">
                    <div id="review-slider" class="owl-carousel">
                        <div class="item">
                            <figure>
                                <img class="ava" src="https://cdn-icons-png.flaticon.com/512/2202/2202112.png"
                                    alt="Reviews Testimonials" style="width:78px; height:78px;" width="78"
                                    height="78" />
                                <figcaption>
                                    <div class="name">Ashley from Austin, Texas</div>
                                    <div class="review">&laquo; Lorem ipsum dolor sit amet, consectetur adipiscing
                                        elit. Aliquam a pulvinar ex. Curabitur at libero ligula. Sed nec felis elit.
                                        Vivamus tincidunt ultrices mi quis elementum. </div>
                                    <div class="b-rate rating4"></div>
                                </figcaption>
                            </figure>
                        </div>
                        <div class="item">
                            <figure>
                                <img class="ava" src="https://cdn-icons-png.flaticon.com/512/2202/2202112.png"
                                    alt="Reviews Testimonials" style="width:78px; height:78px;" width="78"
                                    height="78" />
                                <figcaption>
                                    <div class="name">Rodrigo from Sao Paulo, Brazil</div>
                                    <div class="review">Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                                        Aliquam a pulvinar ex. Curabitur at libero ligula. Sed nec felis elit.
                                        Vivamus tincidunt ultrices mi quis elementum. </div>
                                    <div class="b-rate rating4"></div>
                                </figcaption>
                            </figure>
                        </div>
                        <div class="item">
                            <figure>
                                <img class="ava" src="https://cdn-icons-png.flaticon.com/512/2202/2202112.png"
                                    alt="Reviews Testimonials" style="width:78px; height:78px;" width="78"
                                    height="78" />
                                <figcaption>
                                    <div class="name">Olivier from Paris, France</div>
                                    <div class="review">&laquo; Super stage de pilotage sur un circuit incroyable!
                                        J&rsquo;ai conduit la nouvelle Mc Laren et mon coach &eacute;tait
                                        tr&egrave;s pro, en me donnant des vrais conseils pour piloter sur circuit.
                                        Je conseille cette exp&eacute;rience a tous ceux qui passent par Vegas, vous
                                        ne vivrez ca nulle part ailleurs! &raquo;</div>
                                    <div class="b-rate rating4"></div>
                                </figcaption>
                            </figure>
                        </div>
                        <div class="item">
                            <figure>
                                <img class="ava" src="https://cdn-icons-png.flaticon.com/512/2202/2202112.png"
                                    alt="Reviews Testimonials" style="width:78px; height:78px;" width="78"
                                    height="78" />
                                <figcaption>
                                    <div class="name">Jose from Guadalajara, Mexico</div>
                                    <div class="review">&laquo; Toda la experiencia fue impecable de principio a
                                        fin . El ambiente es muy alegre, y todos son muy amable. Pero tengo que
                                        decir que lo que mas disfrute fue cuando me subi con el instructor en el
                                        Corvette. Estar&eacute; de vuelta pronto. Gracias! &raquo;</div>
                                    <div class="b-rate rating4"></div>
                                </figcaption>
                            </figure>
                        </div>
                    </div>
                </div>
                <div id="video" class="b-video no-video"><img
                        src="https://images.unsplash.com/photo-1552255440-ac1fa0a5b2a3?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=464&q=80"
                        alt="" class="b-video__img img-responsive" />
                    <iframe width="683" height="432" style="border: none;"
                        src="https://www.youtube.com/embed/2N_PCsUDxdA"></iframe>
                </div>
            </section>
            <section class="w-news ">
                <!-- DATA Item code page-block-caption-latest-news -->
                <div class="section-head" style="background:black;">
                    <h2>latest news</h2>
                    <p>Stay in touch with everything that's happening at Exotics Racing</p>
                </div>
                <div class="container">
                    <div class="b-news__container pull-left">
                        <div class="col">
                            <div class="b-social__head"><i class="icon icon-instagram"></i> Follow us on
                                instagram</div>
                            <!--b-social__head-->
                            <div class="b-instargam">
                                <div class="tab-aggregator">
                                    <div class="item-list">
                                        <div class="items" id="instafeed"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="b-social__head">Latest News</div>
                        <div class="tab-aggregator">
                            <div class="item-list">
                                <div class="item ">
                                    <div>
                                        EXOTICS RACING AND SPEEDVEGAS JOIN FORCES TO BECOME SPEEDVEGAS MOTORSPORTS
                                        PARK NOVEMBER 29TH
                                    </div>
                                    <div class="image-background-wrapper">
                                        <a href="news/exotics-racing-and-speed-vegas-join-forces.html"
                                            data-original="https://d1i1eo6qmdfmdv.cloudfront.net/upload/news/61940424aa46a_webside_news.jpg"
                                            style="" class="img image-background read-more lazy "></a>
                                        <div class="image-background-spinner"></div>
                                    </div>
                                    <span>
                                        Nov 16 2021 </span>
                                    <div class="w-text">
                                        Beginning Nov. 29th, Exotics Racing’s elite supercar driving experience will
                                        join forces with SPEEDVEGAS...
                                    </div>
                                    <br>
                                    <br>
                                    <a href="news/exotics-racing-and-speed-vegas-join-forces.html"
                                        class="blue-button read-more">READ MORE</a>
                                    <br>
                                    <br>
                                </div>
                                <div class="item ">
                                    <div>
                                        THE RAIDERS VISIT EXOTICS RACING
                                    </div>
                                    <div class="image-background-wrapper">
                                        <a href="news/The_Raiders_Visit_Exotics_Racing.html"
                                            data-original="https://d1i1eo6qmdfmdv.cloudfront.net/upload/news/5ffc301d2817b_raiders.jpg"
                                            style="" class="img image-background read-more lazy "></a>
                                        <div class="image-background-spinner"></div>
                                    </div>
                                    <span>
                                        Jan 11 2021 </span>
                                    <div class="w-text">
                                        Celebrities love Exotics Racing as much as anybody else, maybe even more!
                                    </div>
                                    <br>
                                    <br>
                                    <a href="news/The_Raiders_Visit_Exotics_Racing.html"
                                        class="blue-button read-more">READ MORE</a>
                                    <br>
                                    <br>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="b-social__container pull-right">
                        <div id="fb-last-posts"></div>
                        <hr>
                        <div class="col">
                            <div class="b-social__head"><i class="icon icon-twitter"></i> Follow us on twitter
                            </div>
                            <div class="b-twitter">
                                <a class="twitter-timeline" href="https://twitter.com/ExoticsRacing"
                                    data-widget-id="423265429562212352"
                                    data-chrome="noheader nofooter noborders">Tweets by @ExoticsRacing</a>
                                <script>
                                    // <![CDATA[
                                    ! function(d, s, id) {
                                        var js, fjs = d.getElementsByTagName(s)[0],
                                            p = /^http:/.test(d.location) ? 'http' : 'https';
                                        if (!d.getElementById(id)) {
                                            js = d.createElement(s);
                                            js.id = id;
                                            js.src = "../platform.twitter.com/widgets.js";
                                            fjs.parentNode.insertBefore(js, fjs);
                                        }
                                    }(document, "script", "twitter-wjs");
                                    // ]]>
                                </script>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- DATA Item code page-block-homepage-stats -->
            <section class="w-stats" style="background:black;">
                <div class="container">
                    <div class="b-stats">
                        <div class="item">
                            <div class="icon icon-satsifiedcustomers"></div>
                            <span class="counter">400,000</span>
                            <p class="caption">Satisfied Customers</p>
                        </div>
                        <div class="item">
                            <div class="icon icon-supercars"></div>
                            <span class="counter">30</span>
                            <p class="caption">Supercars</p>
                        </div>
                        <div class="item">
                            <div class="icon icon-employees"></div>
                            <span class="counter">80</span>
                            <p class="caption">Employees</p>
                        </div>
                    </div>
                </div>
            </section>
        </section>
        <script>
            $(function() {
                $('.summary-panel .top .close').on('click', function(event) {
                    event.preventDefault();
                    $('.summary-panel').hide();
                });
                var movedFlag = false;
                var panel = $('.summary-panel');
                var screenW = $(document).width();
                $('.summary-panel .top').on('mousedown', function(event) {
                    movedFlag = true;
                });
                $("body").on('mousemove', function(event) {
                    var cursorX = event.pageX,
                        cursorY = event.pageY;
                    if (movedFlag) {
                        panel.css({
                            top: cursorY - 45 + 'px',
                            right: screenW - cursorX - 145 + 'px'
                        });
                    }
                }).on('mouseup', function() {
                    movedFlag = false;
                });
            });
        </script>
        <div class="block-layer">
            <img src="img/loader.svg" alt="">
        </div>
    </main>
    <a href="#" class="b-top block">
        <i class="icon icon-backtotop"></i>
        <div class="text">Back
            <small>to top</small>
        </div>
    </a>
    <style>
        .et_bloom .et_bloom_optin_0 .et_bloom_form_content {
            background-color: #333333 !important;
        }

        .et_bloom .et_bloom_optin_0 .et_bloom_form_container .et_bloom_form_header {
            background-color: #dfdfdf !important;
        }

        .et_bloom .et_bloom_optin_0 .curve_edge .curve {
            fill: #dfdfdf
        }

        .et_bloom .et_bloom_optin_0 .et_bloom_form_content button {
            background-color: #ee0000 !important;
        }

        .et_bloom .et_bloom_optin_0 .et_bloom_border_solid {
            border-color: #000000 !important
        }

        .et_bloom .et_bloom_optin_0 .et_bloom_form_content button {
            background-color: #ee0000 !important;
        }

        .et_bloom .et_bloom_optin_0 .et_bloom_form_text h2 {
            font-family: "titillium_webregular", Arial;
            font-size: 2.3em !important;
        }
    </style>
    <div class="et_bloom_popup et_bloom_optin et_bloom_optin_0 et_bloom_resize  et_bloom_auto_popup" data-delay="85"
        data-cookie_duration="30">
        <div
            class="et_bloom_form_container et_bloom_popup_container  with_edge curve_edge et_bloom_with_border et_bloom_border_solid et_bloom_border_position_full et_bloom_form_text_light et_bloom_form_text_light et_bloom_form_text_light et_bloom_animation_zoomin">
            <div class="et_bloom_form_container_wrapper clearfix">
                <div class="et_bloom_header_outer">
                    <div class="et_bloom_form_header split  et_bloom_header_text_ dark">
                        <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/images/subscription/premade-image-05.png"
                            alt="Subscribe To Our Newsletter" class=" et_bloom_image_flipinx et_bloom_image">
                        <div class="et_bloom_form_text">
                            <!-- DATA Item code subscription-block-header -->
                            <h2>Subscribe To Our Newsletter</h2>
                            <p>Join our mailing list to receive up to date information on upcoming races, special
                                offers, events and news from our team!</p>
                        </div>
                    </div>
                </div>
                <div class="et_bloom_form_content et_bloom_1_field et_bloom_bottom_inline et_bloom_custom_html_form"
                    data-account="custom_form" data-optin_id="optin_0" data-service="custom_form"
                    data-list_id="custom_form" data-page_id="-1">
                    <form method="post" class="clearfix">
                        <p class="et_bloom_popup_input et_bloom_subscribe_email">
                            <input placeholder="Email" maxlength="50">
                        </p>
                        <button class="et_bloom_submit_subscription" data-optin_id="optin_0">
                            <span class="et_bloom_subscribe_loader"></span>
                            <span class="et_bloom_button_text et_bloom_button_text_color_light">
                                <!-- DATA Item code subscription-block-cta -->
                                <p>SUBSCRIBE NOW!</p>
                            </span>
                        </button>
                    </form>
                    <div class="et_bloom_success_container">
                        <span class="et_bloom_success_checkmark"></span>
                    </div>
                    <h2 class="et_bloom_success_message">
                        <!-- DATA Item code subscription-block-successfully-registered -->
                        <p>You have Successfully Subscribed!</p>
                    </h2>
                </div>
            </div>
            <span class="et_bloom_close_button"></span>
        </div>
    </div>
    @include('template.footer')
    @include('template.script')

</body>

<!-- Mirrored from exoticsracing.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Aug 2022 09:10:03 GMT -->
