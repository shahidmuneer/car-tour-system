<!DOCTYPE html>
<html prefix="og: http://ogp.me/ns#">
    
<!-- Mirrored from exoticsracing.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Aug 2022 09:06:56 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta id="viewport" name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<link rel="stylesheet" type="text/css" href="assets/2343043f/css/jquery-ui-bootstrap8db0.css?m=1536737786" />
<link rel="stylesheet" type="text/css" href="assets/1c325eb8/css/style8cdb.css?m=1596188684" />
<link rel="stylesheet" type="text/css" href="assets/ca65e889/css/owl.carousel.mina9e0.css?m=1536327774" />
<link rel="stylesheet" type="text/css" href="assets/ca65e889/css/owl.theme.default.mina9e0.css?m=1536327774" />
<link rel="stylesheet" type="text/css" href="assets/d9133a5c/css/bootstrap-exdatepickerae9d.css?m=1578639916" />
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Titillium+Web:600" />
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="themes/wp_exr/libs/bootstrap/css/bootstrap.minefa0.css?m=1661331896" />
<link rel="stylesheet" type="text/css" href="themes/wp_exr/libs/bootstrap/css/bootstrap-responsive.minefa0.css?m=1661331896" />
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.4.2/css/swiper.min.css?m=1661370796" />
<link rel="stylesheet" type="text/css" href="libs/fancybox/jquery.fancybox.minefa0.css?m=1661331896" />
<link rel="stylesheet" type="text/css" href="themes/wp_exr/fonts/icon-fonts/styleefa0.css?m=1661331896" />
<link rel="stylesheet" type="text/css" href="themes/wp_exr/css/mainefa0.css?m=1661331896" />
<link rel="stylesheet" type="text/css" href="themes/wp_exr/css/include__list/stylesheetefa0.css?m=1661331896" />
<link rel="stylesheet" type="text/css" href="themes/wp_exr/css/icons.minefa0.css?m=1661331896" />
<link rel="stylesheet" type="text/css" href="themes/wp_exr/css/customsefa0.css?m=1661331896" />
<link rel="stylesheet" type="text/css" href="fonts/bitsumishi/stylesheetefa0.css?m=1661331896" />
<link rel="stylesheet" type="text/css" href="fonts/manus/stylesheetefa0.css?m=1661331896" />
<link rel="stylesheet" type="text/css" href="fonts/titilliumweb/stylesheetefa0.css?m=1661331896" />
<link rel="stylesheet" type="text/css" href="css/rwdgrid.minefa0.css?m=1661331896" />
<link rel="stylesheet" type="text/css" href="css/new_stylesefa0.css?m=1661331896" />
<style type="text/css">
/*<![CDATA[*/

/*]]>*/
</style>
<script type="text/javascript" src="assets/f784e789/jquery.min.js"></script>
{{-- <script type="text/javascript" src="assets/d9133a5c/js/bootstrap.exdatepickerae9d.js?m=1578639916"></script> --}}
<script type="text/javascript">

/*<![CDATA[*/

                        var phoneCallback = function(formatted_number, unformatted_number) {
                               var numberLinks = document.getElementsByClassName('phone-number');
                               for (var i in numberLinks) {
                                  numberLinks[i].innerHTML = formatted_number;
                               }

                               var clickAction = document.getElementById('click-to-call');
                               if(null != clickAction) {
                                 clickAction.setAttribute('href', 'tel:' + formatted_number);
                               }
                          };

           
var cartOnly = 1;

                    var bloomSettings = {"ajaxurl":"/subscription/subscription/tracking", "pageurl":"", "stats_nonce":"5079895115","subscribe_nonce":"5cad524f0e"} 
/*]]>*/
</script>
<link rel="stylesheet" type="text/css" href="assets/9fcfe31/css/style528a.css?m=1536327706" media="all" />
{{--  --}}    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="asset/css/index.css">
    <style>
    .elementor-element {
    width: 100%;
}
        .elementor-widget-container {
    box-shadow: 5px 5px 2px 0px rgb(0 0 0 / 50%);
}
        .elementor-widget-container {
    -webkit-transition: background .3s,border .3s,border-radius .3s,-webkit-box-shadow .3s;
    transition: background .3s,border .3s,border-radius .3s,-webkit-box-shadow .3s;
    -o-transition: background .3s,border .3s,border-radius .3s,box-shadow .3s;
    transition: background .3s,border .3s,border-radius .3s,box-shadow .3s;
    transition: background .3s,border .3s,border-radius .3s,box-shadow .3s,-webkit-box-shadow .3s;
}
         .elementor-cta {
    display: block;
}
.elementor-kit-5 a {
    color: #405EF6;
}
        .elementor-cta {
    position: relative;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-transition: .5s;
    -o-transition: .5s;
    transition: .5s;
}
.elementor-cta, .elementor-widget-call-to-action .elementor-widget-container {
    overflow: hidden;
}
        .elementor-cta__bg-wrapper {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    -webkit-transition: all .4s;
    -o-transition: all .4s;
    transition: all .4s;
    width: 100%;
}
.elementor-cta__bg-wrapper {
    z-index: 1;
    overflow: hidden;
}
        .elementor-cta__bg-overlay {
    transition-duration: 1500ms;
}
.elementor-bg-transform .elementor-bg {
    will-change: transform;
}
.elementor-cta__bg {
    background-size: cover;
    background-position: 50%;
    z-index: 1;
}
.elementor-cta__bg, .elementor-cta__bg-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    -webkit-transition: all .4s;
    -o-transition: all .4s;
    transition: all .4s;
}
        .elementor-kit-5 a {
    color: #405EF6;
}
        .elementor-cta__content {
    min-height: 435px;
    text-align: center;
    padding: 100px 0px 0px 0px;
}
         .elementor-cta__content-item {
    position: relative;
    -webkit-transition: .5s;
    -o-transition: .5s;
    transition: .5s;
    color: #fff;
}
.elementor-cta__content {
    z-index: 1;
    overflow: hidden;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -ms-flex-line-pack: center;
    align-content: center;
    padding: 35px;
    width: 100%;
}
        .elementor-cta__title {
    font-family: "Anton", Sans-serif;
       font-size: 35px;
    font-weight: 600;
    text-transform: uppercase;
    font-style: italic;
    text-decoration: none;
    color: #FFFFFF;
}
        .elementor-ribbon-right {
    -webkit-transform: rotate(90deg);
    -ms-transform: rotate(90deg);
    transform: rotate(90deg);
    left: auto;
    right: 0;
}

.elementor-ribbon {
    position: absolute;
    z-index: 1;
    top: 0;
    left: auto;
    right: 0;
    -webkit-transform: rotate(90deg);
    -ms-transform: rotate(90deg);
    transform: rotate(90deg);
    width: 150px;
    overflow: hidden;
    height: 150px;
}
        .elementor-ribbon-inner {
    background-color:#FF0000;
    color: #FFFFFF;
    margin-top: 45px;
    transform: translateY(-50%) translateX(-50%) translateX(45px) rotate(-45deg);
    font-family: "Arial", Sans-serif;
    font-size: 12px;
    font-weight: 500;
    text-transform: uppercase;
}
       .elementor-bg-transform-zoom-in:hover .elementor-cta__title {
    color: #FF0000;
}
        .elementor-bg-transform-zoom-in:hover .elementor-bg, .elementor-bg-transform-zoom-out .elementor-bg {
    -webkit-transform: scale(1.2);
    -ms-transform: scale(1.2);
    transform: scale(1.2);
}
         .elementor-cta__bg-overlay {
    transition-duration: 1500ms;
}
        a{
            text-decoration: none !important;
        }
        .row {
            margin-right: 0;
        }
    </style>

<title>Exotics Racing | Las Vegas Supercar Driving Experience</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="The supercar driving experience in Las Vegas. Drive exotic cars like Ferrari, Lamborghini, Porsche, McLaren and others. Book Now!" />
<meta name="keywords" content="racing school, driving experience, las vegas, ferrari, lamborghini, porsche, aston martin, speedway, attractions, exotics, exotic cars, racing, driving, experience, driving school" />

<meta name="twitter:card" content="summary" />
        <meta name="twitter:site" content="@ExoticsRacing" />
        <meta name="twitter:title" content="Exotics Racing | Las Vegas Supercar Driving Experience" />
        <meta name="twitter:description" content="The supercar driving experience in Las Vegas. Drive exotic cars like Ferrari, Lamborghini, Porsche, McLaren and others. Book Now!" />
        <meta name="twitter:image" content="https://exoticsracing.com/img/logo/footer_logo.png" /><meta property="og:site_name" content="ExoticsRacing" />
        <meta property="og:type" content="website" />
        <meta property="og:title" content="Exotics Racing | Las Vegas Supercar Driving Experience" />
        <meta property="og:description" content="The supercar driving experience in Las Vegas. Drive exotic cars like Ferrari, Lamborghini, Porsche, McLaren and others. Book Now!" />
        <meta property="og:url" content="https://exoticsracing.com/" />
        <meta property="og:image" content="https://exoticsracing.com/img/logo/footer_logo.png" /><script type="application/ld+json">
        {
            "@context": "http://schema.org",
            "@type": "WebPage",
            "name": "Exotics Racing | Las Vegas Supercar Driving Experience",
            "description": "The supercar driving experience in Las Vegas. Drive exotic cars like Ferrari, Lamborghini, Porsche, McLaren and others. Book Now!",
            "publisher": {
                "@type": "Organization",
                "name": "ExoticsRacing"
            }
        }
        </script>        <link rel="shortcut icon" href="images/favicon.png" type="image/x-png">
        <script type="application/ld+json">
            {
              "@context" : "http://schema.org",
              "@type" : "Organization",
              "name" : "ExoticsRacing",
              "url" : "https://exoticsracing.com",
              "sameAs" : [ 
                "https://www.facebook.com/exoticsracing", 
                "https://www.instagram.com/exoticsracing/",
                "https://www.youtube.com/user/exoticsracingschool"
              ],
              "logo" : "https://exoticsracing.com/img/logo/footer_logo.png",
              "contactPoint" : [{
                "@type" : "ContactPoint",
                "telephone" : "+1 (702) 800-0521",
                "contactType" : "customer service"
              }]
            }
        </script>
        <!-- SEO lang urls start -->
                    <link rel="canonical" href="index.html" hreflang="en" />
                    <link rel="alternate" href="es/index.html" hreflang="es" />
                    <link rel="alternate" href="fr/index.html" hreflang="fr" />
                    <link rel="alternate" href="pt/index.html" hreflang="pt" />
                <!-- SEO lang urls end -->

        <noscript>
            <img height="1" width="1" style="display:none"src="https://www.facebook.com/tr?id=389760194513806&amp;ev=PageView&amp;noscript=1"/>
        </noscript>
        <!-- DO NOT MODIFY -->
        <!-- End Facebook Pixel Code -->
    </head>
    <body onclick="void(0)" class="et_bloom homepage"  onload="_googWcmGet(phoneCallback, '+1 (702) 800-0521')"><script type="text/javascript">

</script>
        <!-- End Google Tag Manager (noscript) -->
        <header>
            <div class="overlay_menu"></div>
            <div class="b-fixed__nav">
    <div class="w-social__line">
        <div class="container">
            <div class="line">
                <a class="lang-ico lang-en current" href="#"></a>
<ul class="b-lang unstyled-list pull-right">
            <li>
            <a class="block lang-ico lang-es" href="es/index.html"></a>
        </li>
            <li>
            <a class="block lang-ico lang-fr" href="fr/index.html"></a>
        </li>
            <li>
            <a class="block lang-ico lang-pt" href="pt/index.html"></a>
        </li>
    </ul>
                <ul class="b-social unstyled-list pull-right">
                    <li>
                        <a href="https://www.facebook.com/exoticsracing" class="block" target="_blank">
                            <i class="icon-facebook"></i>
                        </a>
                    </li>
                    <li>
                        <a href="https://www.instagram.com/exoticsracing/" class="block" target="_blank">
                            <i class="icon-instagram"></i>
                        </a>
                    </li>
                    <li>
                        <a href="http://www.youtube.com/user/exoticsracingschool" class="block" target="_blank">
                            <i class="icon-youtube"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <nav class="w-nav">
        <div class="b-nav container">
            <a href="index.html" class="b-logo__main block">&nbsp;</a>
                            <ul id="super-menu" class="b-menu unstyled-list">
                                                                        <li class="b-dropdown">
                                <a class="dropdown-toggle" href="las-vegas-supercar-driving-experience.html">
                                    SUPERCAR                                </a>
                                <ul class="b-dropdown__menu level1 dropdown-menu unstyled-list">
                                    <li class="b-dropdown relative">
    <a href="las-vegas-supercar-driving-experience.html"  class="sf-with-ul" data-track="1">
        Overview        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown">
    <a href="fleet/vehicle/ourExotics.html" >
        <span class="name">
            Supercars        </span>
        <i class="icon "></i>
    </a>
    <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                                    <li class="b-dropdown relative">
    <a href="driving-experience/speed-vegas-motorsport-park/our-exotic-cars.html"  class="sf-with-ul" >
        All Supercars        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li>                                                                <li class="b-dropdown">
                    <a href="driving-experience/drive-ferrari.html"  class="model-link" >
                        <span class="name">
                            Ferrari                        </span>
                        <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/menu/Ferrari488PistaProfile-1%202.png" alt="Ferrari"/>
                    </a>
                        <ul id="models-2-level" class="b-dropdown__menu levels level3 dropdown-menu unstyled-list models-list">
        <li class="b-dropdown"><a href="driving-experience/drive-ferrari.html" ><span>All Ferraris</span></a></li>                <li class="b-dropdown">
                    <a href="driving-experience/ferrari-f430-f1.html"  class="model-link" >
                        <span>
                            Ferrari F430 F1                        </span>
                        <div class="bonuses-container">
                                                                                </div>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="1" name="model_id">
                <li data-id="1"></li>
    </form>
</ul>                </li>
                                <li class="b-dropdown">
                    <a href="driving-experience/ferrari-488-gtb.html"  class="model-link" >
                        <span>
                            Ferrari 488 GTB                        </span>
                        <div class="bonuses-container">
                                                            <i class="bestseller" title="Bestseller"></i>
                                                                                </div>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="106" name="model_id">
                <li data-id="106"></li>
    </form>
</ul>                </li>
                                <li class="b-dropdown">
                    <a href="driving-experience/ferrari-488-challenge-evo.html"  class="model-link" >
                        <span>
                            Ferrari 488 Challenge Evo                        </span>
                        <div class="bonuses-container">
                                                                                </div>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="143" name="model_id">
                <li data-id="143"></li>
    </form>
</ul>                </li>
                                <li class="b-dropdown">
                    <a href="driving-experience/ferrari-488-pista.html"  class="model-link" >
                        <span>
                            Ferrari 488 Pista                        </span>
                        <div class="bonuses-container">
                                                                                </div>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="127" name="model_id">
                <li data-id="127"></li>
    </form>
</ul>                </li>
                    </ul>
                </li>
                                                                <li class="b-dropdown">
                    <a href="driving-experience/drive-lamborghini.html"  class="model-link" >
                        <span class="name">
                            Lamborghini                        </span>
                        <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/menu/L17.png" alt="Lamborghini"/>
                    </a>
                        <ul id="models-2-level" class="b-dropdown__menu levels level3 dropdown-menu unstyled-list models-list">
        <li class="b-dropdown"><a href="driving-experience/drive-lamborghini.html" ><span>All Lamborghinis</span></a></li>                <li class="b-dropdown">
                    <a href="driving-experience/lamborghini-gallardo-lp550.html"  class="model-link" >
                        <span>
                            Lamborghini Gallardo LP550-2                        </span>
                        <div class="bonuses-container">
                                                                                </div>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="4" name="model_id">
                <li data-id="4"></li>
    </form>
</ul>                </li>
                                <li class="b-dropdown">
                    <a href="driving-experience/lamborghini-huracan-lp580-2.html"  class="model-link" >
                        <span>
                            Lamborghini Huracan LP580-2                        </span>
                        <div class="bonuses-container">
                                                            <i class="bestseller" title="Bestseller"></i>
                                                                                </div>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="31" name="model_id">
                <li data-id="31"></li>
    </form>
</ul>                </li>
                                <li class="b-dropdown">
                    <a href="driving-experience/lamborghini-huracan-sto.html"  class="model-link" >
                        <span>
                            Lamborghini Huracan STO                        </span>
                        <div class="bonuses-container">
                                                                                </div>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="132" name="model_id">
                <li data-id="132"></li>
    </form>
</ul>                </li>
                                <li class="b-dropdown">
                    <a href="driving-experience/lamborghini-super-trofeo-evo.html"  class="model-link" >
                        <span>
                            Lamborghini Huracan Super Trofeo Evo                        </span>
                        <div class="bonuses-container">
                                                                                        <i class="car-of-the-week"
                                   title="Car of the week, $100 discount">
                                    <span class="car-of-the-week-icon-price">
                                    $100 OFF                                </span>
                                </i>
                                                    </div>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="145" name="model_id">
                <li data-id="145"></li>
    </form>
</ul>                </li>
                    </ul>
                </li>
                                                                <li class="b-dropdown">
                    <a href="driving-experience/drive-porsche.html"  class="model-link" >
                        <span class="name">
                            Porsche                        </span>
                        <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/menu/GT2RS2%20_1_.png" alt="Porsche"/>
                    </a>
                        <ul id="models-2-level" class="b-dropdown__menu levels level3 dropdown-menu unstyled-list models-list">
        <li class="b-dropdown"><a href="driving-experience/drive-porsche.html" ><span>All Porsches</span></a></li>                <li class="b-dropdown">
                    <a href="driving-experience/porsche-cayman-gts.html"  class="model-link" >
                        <span>
                            Porsche 718 Cayman GTS                        </span>
                        <div class="bonuses-container">
                                                                                </div>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="102" name="model_id">
                <li data-id="102"></li>
    </form>
</ul>                </li>
                                <li class="b-dropdown">
                    <a href="driving-experience/porsche-cayman-gt4.html"  class="model-link" >
                        <span>
                            Porsche 718 Cayman GT4                        </span>
                        <div class="bonuses-container">
                                                                                </div>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="140" name="model_id">
                <li data-id="140"></li>
    </form>
</ul>                </li>
                                <li class="b-dropdown">
                    <a href="driving-experience/porsche-992-gt3.html"  class="model-link" >
                        <span>
                            Porsche 992 GT3                        </span>
                        <div class="bonuses-container">
                                                                                </div>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="126" name="model_id">
                <li data-id="126"></li>
    </form>
</ul>                </li>
                                <li class="b-dropdown">
                    <a href="driving-experience/porsche-911-gt3-rs-gen1.html"  class="model-link" >
                        <span>
                            Porsche 991 GT3 RS                        </span>
                        <div class="bonuses-container">
                                                                                </div>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="95" name="model_id">
                <li data-id="95"></li>
    </form>
</ul>                </li>
                                <li class="b-dropdown">
                    <a href="driving-experience/porsche-gt2-rs.html"  class="model-link" >
                        <span>
                            Porsche 991 GT2 RS                        </span>
                        <div class="bonuses-container">
                                                                                </div>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="125" name="model_id">
                <li data-id="125"></li>
    </form>
</ul>                </li>
                    </ul>
                </li>
                                                                <li class="b-dropdown">
                    <a href="driving-experience/mercedes-benz-amg-gtr.html"  class="model-link" >
                        <span class="name">
                            Mercedes                        </span>
                        <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/menu/AMG-GTR%20cutout.png" alt="Mercedes"/>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="118" name="model_id">
                <li data-id="118"></li>
    </form>
</ul>                </li>
                                                                <li class="b-dropdown">
                    <a href="driving-experience/audi-r8-v10-plus.html"  class="model-link" >
                        <span class="name">
                            Audi                        </span>
                        <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/menu/R8V10Plus-cutout2.png" alt="Audi"/>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="114" name="model_id">
                <li data-id="114"></li>
    </form>
</ul>                </li>
                                                                <li class="b-dropdown">
                    <a href="driving-experience/drive-corvette.html"  class="model-link" >
                        <span class="name">
                            Corvette                        </span>
                        <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/corvettec8.png" alt="Corvette"/>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="101" name="model_id">
                <li data-id="101"></li>
    </form>
</ul>                </li>
                                                                <li class="b-dropdown">
                    <a href="driving-experience/mclaren-gt4.html"  class="model-link" >
                        <span class="name">
                            McLaren                        </span>
                        <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/img/car_sm/mclaren.png" alt="McLaren"/>
                    </a>
                        <ul id="models-2-level" class="b-dropdown__menu levels level3 dropdown-menu unstyled-list models-list">
        <li class="b-dropdown"><a href="driving-experience/mclaren-gt4.html" ><span>All McLarens</span></a></li>                <li class="b-dropdown">
                    <a href="driving-experience/mclaren-570s.html"  class="model-link" >
                        <span>
                            McLaren 570s                        </span>
                        <div class="bonuses-container">
                                                                                </div>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="107" name="model_id">
                <li data-id="107"></li>
    </form>
</ul>                </li>
                                <li class="b-dropdown">
                    <a href="driving-experience/mclaren-gt4.html"  class="model-link" >
                        <span>
                            McLaren 570 GT4                        </span>
                        <div class="bonuses-container">
                                                                                </div>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="142" name="model_id">
                <li data-id="142"></li>
    </form>
</ul>                </li>
                    </ul>
                </li>
                                                                <li class="b-dropdown">
                    <a href="driving-experience/aston-martin-vantage.html"  class="model-link" >
                        <span class="name">
                            Aston Martin                        </span>
                        <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/menu/Aston_Martin_V8_Vantage_AMV_8_-_Portugal-_3_.png" alt="Aston Martin"/>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="14" name="model_id">
                <li data-id="14"></li>
    </form>
</ul>                </li>
                                                                <li class="b-dropdown">
                    <a href="driving-experience/nissan-gt-r.html"  class="model-link" >
                        <span class="name">
                            Nissan                        </span>
                        <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/menu/2017_nissan_gtr_Cutout2.png" alt="Nissan"/>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="15" name="model_id">
                <li data-id="15"></li>
    </form>
</ul>                </li>
                                                                <li class="b-dropdown">
                    <a href="driving-experience/acura-nsx.html"  class="model-link" >
                        <span class="name">
                            Acura                        </span>
                        <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/acura_nsx/acura-nsx.png" alt="Acura"/>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="109" name="model_id">
                <li data-id="109"></li>
    </form>
</ul>                </li>
                                                                <li class="b-dropdown">
                    <a href="driving-experience/shelby-gt500.html"  class="model-link" >
                        <span class="name">
                            Ford                        </span>
                        <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/img/car_sm/gt500_listview.png" alt="Ford"/>
                    </a>
                    <ul class="b-car__info b-dropdown__menu levels level4 dropdown-menu unstyled-list">
    <form method="post" action="https://exoticsracing.com/driving-experience" name="bookExperience" class="b-specs-rm">
        <input id="model_id" type="hidden" value="129" name="model_id">
                <li data-id="129"></li>
    </form>
</ul>                </li>
                                                <li class="b-dropdown relative">
    <a href="driving-experience.html"  class="sf-with-ul" >
        Customize Your Experience        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li>                        </ul>
</li>
<li class="b-dropdown relative">
    <a href="driving-experience/combos.html"  class="sf-with-ul" data-track="1">
        Multiple Car Packages        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="driving-experience/high-performance-driving-experiences.html"  class="sf-with-ul" data-track="1">
        1-Day Driving Experience        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
            <li class="b-dropdown relative">
    <a href="driving-experience/high-performance-driving-experiences.html"  class="sf-with-ul" >
        Overview        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="driving-experience/1-Day-Corvette-High-Performance-Driving-Experience.html"  class="sf-with-ul" >
        Corvette C8 Z51        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="driving-experience/1-Day-Porsche-High-Performance-Driving-Experience.html"  class="sf-with-ul" >
        Porsche GT3 RS        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="driving-experience/1-Day-McLaren-High-Performance-Driving-Experience.html"  class="sf-with-ul" >
        McLaren GT4        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="driving-experience/1-Day-Ferrari-Evo-High-Performance-Driving-Experience.html"  class="sf-with-ul" >
        Ferrari Evo        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="driving-experience/1-Day-Lamborghini-High-Performance-Driving-Experience.html"  class="sf-with-ul" >
        Lamborghini Supertrofeo        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li>        </ul>
    </li><li class="b-dropdown relative">
    <a href="driving-experience/vip-experience.html"  class="sf-with-ul" data-track="1">
        VIP Experiences        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="driving-experience/drifting-supercar-ride-along-experience.html"  class="sf-with-ul" data-track="1">
        Ride-Along        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="#"  class="sf-with-ul" >
        EXR Time Trial Standings        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
            <li class="b-dropdown relative">
    <a href="exr-time-trial-world-challenge.html"  class="sf-with-ul" >
        Standings        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="driver-profile.html"  class="sf-with-ul" >
        Driver Profile        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li>        </ul>
    </li><li class="b-dropdown relative">
    <a href="driving-experience/speed-vegas-motorsport-park/gift-certificate.html"  class="sf-with-ul" data-track="1">
        Gift Packages        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li>                                </ul>
                            </li>
                                                                                        
                                                                                                <li class="b-dropdown">
                                <a class="dropdown-toggle" href="vegas-superkarts-outdoor-go-kart.html">
                                    Go-Kart                                </a>
                                <ul class="b-dropdown__menu level1 dropdown-menu unstyled-list">
                                    <li class="b-dropdown relative">
    <a href="go-kart/arrive-and-drive.html"  class="sf-with-ul" >
        Arrive & Drive        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="#"  class="sf-with-ul" >
        Standings        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
            <li class="b-dropdown relative">
    <a href="go-kart-las-vegas-standings.html"  class="sf-with-ul" >
        Timing Leaderboard        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="exr-gokarts-driver-profile.html"  class="sf-with-ul" >
        Driver Profile        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li>        </ul>
    </li><li class="b-dropdown relative">
    <a href="go-kart/group-events.html"  class="sf-with-ul" >
        Groups        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="go-kart/gift-certificate.html"  class="sf-with-ul" >
        Gift Certificates        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li>                                </ul>
                            </li>
                                                                                                <li class="b-dropdown">
                                <a class="dropdown-toggle" href="driving-experience-off-road.html">
                                    Off-Road                                </a>
                                <ul class="b-dropdown__menu level1 dropdown-menu unstyled-list">
                                    <li class="b-dropdown relative">
    <a href="driving-experience-off-road.html"  class="sf-with-ul" >
        Track Experiences        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="driving-experience-off-road-hpde.html"  class="sf-with-ul" >
        1-Day Off-Road Driving Experience	        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="off-road/gift-certificate.html"  class="sf-with-ul" >
        Gift Certificates        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li>                                </ul>
                            </li>
                                                                                                <li class="b-dropdown">
                                <a class="dropdown-toggle" href="group-corporate-events.html">
                                    Groups                                </a>
                                <ul class="b-dropdown__menu level1 dropdown-menu unstyled-list">
                                    <li class="b-dropdown relative">
    <a href="group-corporate-events.html"  class="sf-with-ul" data-track="1">
        Corporate Events        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="las-vegas-bachelor-party.html"  class="sf-with-ul" data-track="1">
        Bachelor Parties / Groups        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li>                                </ul>
                            </li>
                                                                                                <li class="b-dropdown">
                                <a class="dropdown-toggle" href="#">
                                    About us                                </a>
                                <ul class="b-dropdown__menu level1 dropdown-menu unstyled-list">
                                    <li class="b-dropdown relative">
    <a href="hours-and-directions.html"  class="sf-with-ul" >
        Hours & Directions        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="faqs.html"  class="sf-with-ul" >
        FAQs        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="about-us.html"  class="sf-with-ul" >
        Who we Are?        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="racetrack.html"  class="sf-with-ul" >
        The Racetrack        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="reviews.html"  class="sf-with-ul" >
        Reviews        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="media.html"  class="sf-with-ul" >
        Media / Galleries        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="careers.html"  class="sf-with-ul" >
        Careers        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li><li class="b-dropdown relative">
    <a href="contact-us.html"  class="sf-with-ul" >
        Contact Us        <i class="icon "></i>
    </a>
            <ul class="b-dropdown__menu levels level2 dropdown-menu unstyled-list">
                    </ul>
    </li>                                </ul>
                            </li>
                                                            </ul>
                <div class="w-booking">
                    <strong class="block">
                        + x(xxx)xxx-xxx                  </strong>
                    <a id="_menu_book_now" style="background:red!important;" href="driving-experience.html" 
                    class="b-btn__book btn-block green-button">
                        book now                    
                    </a>
                </div>
                        <div class="w-control__site">
                                    <a class="b-login" href="user/login.html">
                        <span></span>
                        <div class="caption">
                            Login                        </div>
                    </a>
                                <a href="cart.html" class="b-cart">
                    <span></span>
                    <div class="caption">
                        Cart                    </div>
                </a>      
            </div>
        </div>
    </nav>
</div>        </header>
        <main>
                        <div class="w-carousel">
                            <div id="slider" class="b-carousel owl-carousel ">
                                <!-- DATA Item code page-slider-homepage --><div class="item">
                                    
<div class="w-video__slide embed-responsive embed-responsive-16by9" data-youtube-id="2N_PCsUDxdA" data-youtube-mute="1" data-youtube-autoplay="1" data-youtube-volume="0"></div>
</div>
<div class="item"><img 
   style="height:670px;"
    src="https://images.unsplash.com/photo-1593693044238-f14e5b164e75?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1332&q=80" alt="New Location" width="1800" height="700" /></div>
<div class="item"><img class="block" 
   style="height:670px;"
    src="https://images.unsplash.com/photo-1621431057082-56fc8f3d49c4?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"  />
<div class="w-caption bottom-left">
<div class="caption">
<div class="head"><strong>THE FASTEST AND MOST ENJOYABLE CIRCUIT IN LAS VEGAS</strong></div>
<!--head-->The Exotics Racing racetrack was specifically designed for supercars with a variety of turns, safety features, and the fastest straight away.</div>
<a class="b-btn__bone" href="las-vegas-supercar-driving-experience.html"> <span class="text">SUPERCAR DRIVING EXPERIENCE</span> <span class="icon"><span></span></span> <span class="icon2"></span> </a></div>
<!--caption--></div>
<div class="item"><img class="block" 
    
      style="height:600px;"
    src="https://images.unsplash.com/photo-1528501028382-e587fcf3a03e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80" alt="Happy Customers"  />
<div class="w-caption bottom-left">
<div class="caption">
<div class="head"><strong>VOTED #1 DRIVING EXPERIENCE <br />BY OUR 260,000 <g class="gr_ gr_41 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="41" data-gr-id="41">CUSTOMERS </g> </strong></div>
<!--head--> <g class="gr_ gr_41 gr-alert gr_spell gr_inline_cards gr_disable_anim_appear ContextualSpelling ins-del multiReplace" id="41" data-gr-id="41">As </g> a multi-award-winning attraction, we&rsquo;ve earned kudos from our 260,000+ satisfied clients who have enjoyed our world-class <g class="gr_ gr_40 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del" id="40" data-gr-id="40">super car </g> driving experience at our two exclusive tracks.</div>
<a class="b-btn__bone" href="reviews.html"> <span class="text">customer reviews</span> <span class="icon"><span></span></span> <span class="icon2"></span> </a></div>
</div>
<div class="item"><img 
    
   style="height:600px;"
    src="https://images.unsplash.com/photo-1520340356584-f9917d1eea6f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1331&q=80" alt="Celebrities"  />
<div class="w-caption bottom-right" style="bottom: 7%; right: 6%;"><a class="b-btn__bone" href="vegas-superkarts-outdoor-go-kart.html"> <span class="text">GO-KART</span> <span class="icon"><span></span></span> <span class="icon2"></span> </a></div>
</div>
<div class="item"><img 
   style="height:600px;"
   src="https://images.unsplash.com/photo-1526550517342-e086b387edda?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1229&q=80" alt="Celebrities"  />
<div class="w-caption center">
<div class="caption">
<div class="head"><strong>CELEBRITY CONNECTION</strong></div>
You never know who you will see at Exotics Racing! From Lebron James to Zac Efron, compare your lap-time with many celebrities, including Formula One drivers, who are ranked in the Exotics Racing Time Trial Challenge and see if you are faster than them on our racetrack!</div>
<a class="b-btn__bone" href="https://exoticsracing.com:443/galleries/hall-of-fame"> <span class="text">hall of fame</span> <span class="icon"><span></span></span> <span class="icon2"></span> </a></div>
<!--caption--></div>
<!--<div class="item"><img src="https://d1i1eo6qmdfmdv.cloudfront.net/upload/Slider-1800x700-Homepage-HPDE.jpg" alt="Racing School and HPDE" class="poster block"  />
<div class="w-caption bottom-right">
<table class="text-center">
<tbody>
<tr>
<td><img src="https://d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/30.png" alt="" />
<div class="text">1-Day Porsche HPDE | $1,990</div>
<a class="blue-button" href="/experience/booking/create/gift_package_id/24">BOOK NOW</a></td>
</tr>
</tbody>
</table>
</div>
</div>--></div>
<!-- 
<div class="overlay"></div>
<div class="car-selection-head">
    <ul>
                    <li data-id="65">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/porsche_cayman_gts/Cayman-718-listview.png">
                </a>
            </li>
                    <li data-id="141">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/porsche_cayman_gt4/PORSCHE_CAYMAN_GT4_listview1.png">
                </a>
            </li>
                    <li data-id="14">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/15.png">
                </a>
            </li>
                    <li data-id="15">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/aston_martin_vantage_s/vantage-gt-listview.png">
                </a>
            </li>
                    <li data-id="66">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/corvette_c8/new/corvettec8-listview.png">
                </a>
            </li>
                    <li data-id="4">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/1.png">
                </a>
            </li>
                    <li data-id="107">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/mercedes_amg_gtr/Mercedes-AMG-GTR-listview.png">
                </a>
            </li>
                    <li data-id="7">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/4.png">
                </a>
            </li>
                    <li data-id="88">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/109.png">
                </a>
            </li>
                    <li data-id="129">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/shelby-gt500/gt500_listview.png">
                </a>
            </li>
                    <li data-id="101">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/audi_r8_v10_plus/R8V10Plus-listview.png">
                </a>
            </li>
                    <li data-id="126">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/porsche_992_gt3/992_GT3_listview.png">
                </a>
            </li>
                    <li data-id="60">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/lamborghini_huracan_lp610/huracan-listview.png">
                </a>
            </li>
                    <li data-id="83">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/porsche_911_gt3_rs/porsche-gt3rs_listing.png">
                </a>
            </li>
                    <li data-id="11">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/107.png">
                </a>
            </li>
                    <li data-id="78">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/106.png">
                </a>
            </li>
                    <li data-id="127">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/ferrari_488_pista/ferrari-488-pista-listview.png">
                </a>
            </li>
                    <li data-id="132">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/lamborghini_huracan_sto/huracan_sto_listview.png">
                </a>
            </li>
                    <li data-id="125">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/porsche_gt2_rs/GT2RS-listview.png">
                </a>
            </li>
                    <li data-id="153">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/mclaren_570gt4/EXR_MCLAREN_NEW_570_GT4_CUTOUT_list.png">
                </a>
            </li>
                    <li data-id="157">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/ferrari_488_challenge_evo/FERRARI_488_CHALLENGE_listview.png">
                </a>
            </li>
                    <li data-id="166">
                <a href="javascript:void(0);">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/lamborghini_supertrofeo/Super-Trofeo-EVO_listview.png">
                </a>
            </li>
            </ul>
    <div id="car-place" class="w-product__stats"></div>
</div> -->
</div>    
<section class="w-experiences" >
        <div class="b-experience__search" style="background:black;">
    <form class="" data-ajax="false" id="inlineForm" action="https://exoticsracing.com/driving-experience/search" method="GET">        <div class="w-select track">
            <select class="b-select" name="SearchBoxForm[track]" id="SearchBoxForm_track">
<option value="">CHOOSE YOUR EXPERIENCE</option>
<option value="1">Exotics Racing Supercar Racetrack</option>
<option value="153">Vegas Superkarts Go-Kart Track</option>
<option value="158">Vegas Off-Road Experience Dirt Track</option>
</select>            <i class="icon icon-angle-down"></i>
        </div>
        <div class="w-select car">
            <select class="b-select" name="SearchBoxForm[category]" id="SearchBoxForm_category">
<option value="">CHOOSE YOUR VEHICLE</option>
<option value="22">Drive a Go-Kart</option>
<option value="3">Drive a Ferrari</option>
<option value="4">Drive a Lamborghini</option>
<option value="5">Drive a Porsche</option>
<option value="6">Drive a McLaren</option>
<option value="7">Drive an Audi R8</option>
<option value="8">Drive a Nissan GT-R</option>
<option value="39">$699 / 5 laps</option>
<option value="11">Drive a Corvette</option>
<option value="10">Drive a Mercedes-Benz</option>
<option value="25">Drive an Off-Road Baja Truck</option>
<option value="23">Drive a Mustang</option>
<option value="17">Drifting Ride-Along</option>
<option value="2">Ride-Along Experience</option>
<option value="16">Supercar Ride-Along</option>
</select>            <i class="icon icon-angle-down"></i>
        </div>
        <div class="w-select date">
            <input class="b-select" placeholder="Select Date" type="text" autocomplete="off" name="SearchBoxForm[date]" id="SearchBoxForm_date" /><script>$('#SearchBoxForm_date').bexdatepicker({'autoclose':true,'startDate':'1d','checkAvailableDates':true,'availableDates':[],'language':'en','format':'mm\x2Fdd\x2Fyyyy','weekStart':0})</script>            <i class="icon icon-calendar"></i>
        </div>
        <div class="w-btn__search">
            <button class="b-btn__book search styled block" style="background:red;" type="submit">
                <span class="text">search</span>
            </button>
        </div><!--w-btn__search-->
    </form></div>                    <section class="w-section" style="padding-top: 20px;">
                <!-- DATA Item code page-block-homepage-header --><div class="top-section-head">
<p></p>
<h1>DRIVE SUPERCARS TO THE LIMIT<br />ON THE FASTEST&nbsp;&amp; SAFEST RACETRACK IN LAS VEGAS</h1>
<p>As the original, best rated and world's largest supercar driving experience, Exotics Racing lets you choose from over 40 exotic cars.<br /> What would you like to drive today? A Ferrari or a Lamborghini? A Porsche or a McLaren? How about all of them?<br /> Now you can on our exclusive racetrack designed to offer the most exhilarating driving experience ever.</p>
</div>            </section>
                <!-- DATA Item code page-block-homepage-vip-group-events --><section class="w-promo">
{{-- <div class="container">
<div class="item">
<div style="background-image: url('https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercar-227-600x500-1-300x250.jpg');" class="img-responsive"></div>
<div class="overlay">
<div class="b-promo-content">
<h3 class="title">SUPERCAR DRIVING EXPERIENCES<br />LAS VEGAS RACETRACK</h3>
<p>As the original, best rated and world's largest supercar driving experience, we let you drive our fleet of over 40 exotic cars on the fastest and safest racetrack in Las Vegas.<br />You will be able to drive our supercars coached by our team of friendly experts to have the most exhilarating driving experience ever!<br />No stress, we take care of everything! Technical Briefing, Discovery Laps, Supercars, Lap Times, Private Coaching, Helmets &amp; Insurance. You can aslo add to your experience the On-board Video, a Photo, our famous Drifting Ride-Along or some Go-Kart Races.</p>
<br />
<div style="text-align: center;"><a href="las-vegas-supercar-driving-experience.html" class="btn">LEARN MORE</a></div>
</div>
</div>
</div>
<div class="item">
<div style="background-image: url('https://images.unsplash.com/photo-1552255472-3330e5928013?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=464&q=80');" class="img-responsive"></div>
<div class="overlay">
<div class="b-promo-content">
<h3 class="title">GROUPS</h3>
<p><b>GROUPS</b><br />Exotics Racing provides groups a unique venue to host a top-level event for your corporate or personal guests. Our dedicated team is at your disposal to help you build an incomparable event.</p>
<br />
<div style="text-align: center;"><a href="las-vegas-bachelor-party.html" class="btn btn">groups</a></div>
<div style="text-align: center;"><a href="group-corporate-events.html" class="btn-invert">corporate events</a></div>
<br />
<h3 class="title">VIP EXPERIENCES</h3>
<p><b>VIP EXPERIENCES</b><br />From the VIP Concierge Service and private business lounge access to dedicated one-on-one coaching, personalize your unforgettable VIP experience with us.</p>
<br />
<div style="text-align: center;"><a href="driving-experience/vip-experience-2.html" class="btn">learn more</a></div>
<br />
<h3 class="title">GIFT PACKAGES</h3>
<p><b>GIFT PACKAGES</b><br />An Exotics Racing driving experience is the most exhilarating gift for any occasion. With our all-inclusive pricing, select a pre-built gift package or specify your own dollar amount and offer the gift of a lifetime!</p>
<br />
<div style="text-align: center;"><a href="driving-experience/gift-ideas.html" class="btn">learn more</a></div>
</div>
</div>
</div>
<div class="item">
<div style="background-image: url('https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercar-Pics-600x500-1.jpg');" class="img-responsive"></div>
<div class="overlay">
<div class="b-promo-content">
<h3 class="title"><g class="gr_ gr_34 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling ins-del multiReplace" id="34" data-gr-id="34">GO-KART<br />LAS VEGAS</g></h3>
<p>Race against your friends with the best go-kart equipment at VEGAS SUPERKARTS! Our brand-new outdoor racetrack ensures high safety and fun for anyone racing with us. There is no other place in Las Vegas where you can find what we offer, so if you want to race the best go karts, come race with us!</p>
<br />
<div style="text-align: center;"><a href="vegas-superkarts-outdoor-go-kart.html" class="btn">learn more</a></div>
</div>
</div>
</div>
<div class="item">
<div style="background-image: url('https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercars-244-600x500-overlay.jpg');" class="img-responsive"></div>
<div class="overlay">
<div class="b-promo-content">
<h3 class="title">Off Road<br />VEGAS OFF-ROAD</h3>
<p>Experience the thrill of driving a FORD Race Truck on our 1 mile off-road track. Defy gravity on eight jumps that will launch you up to 10 feet into the air.</p>
<br />
<div style="text-align: center;"><a href="driving-experience-off-road.html" class="btn">Learn More</a></div>
</div>
</div>
</div>
</div> --}}
<div class="row m-0 p-0">
        <div class="col-lg-3">
            <div class="elementor-element elementor-element-82c41b7 elementor-cta--skin-cover elementor-cta--valign-top elementor-animated-content elementor-bg-transform elementor-bg-transform-zoom-in elementor-widget elementor-widget-call-to-action" data-id="82c41b7" data-element_type="widget" data-widget_type="call-to-action.default">
                <div class="elementor-widget-container">
                    <a class="elementor-cta" href="/supercar-track-days">
                    <div class="elementor-cta__bg-wrapper">
                <div class="elementor-cta__bg elementor-bg" style="background-image:url(' https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercars-244-600x500-overlay.jpg')"></div>
                <div class="elementor-cta__bg-overlay"></div>
            </div>
                            <div class="elementor-cta__content" style="text-align: center;">
                
                <h2 class="elementor-cta__title elementor-cta__content-item elementor-content-item elementor-animated-item--grow">TRACK DAYS</h2>
                
                            </div>
                            <div class="elementor-ribbon elementor-ribbon-right">
                <div class="elementor-ribbon-inner">Private Track</div>
            </div>
                </a>
                </div>
                </div>
            </div>
            
            <div class="col-lg-3">
            <div class="elementor-element elementor-element-82c41b7 elementor-cta--skin-cover elementor-cta--valign-top elementor-animated-content elementor-bg-transform elementor-bg-transform-zoom-in elementor-widget elementor-widget-call-to-action" data-id="82c41b7" data-element_type="widget" data-widget_type="call-to-action.default">
                <div class="elementor-widget-container">
                    <a class="elementor-cta" href="/supercar-track-days">
                    <div class="elementor-cta__bg-wrapper">
                <div class="elementor-cta__bg elementor-bg" style="background-image:url('https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercars-233-600x500-overlay.jpg')"></div>
                <div class="elementor-cta__bg-overlay"></div>
            </div>
                            <div class="elementor-cta__content">
                
                <h2 class="elementor-cta__title elementor-cta__content-item elementor-content-item elementor-animated-item--grow">Tour Days</h2>
                
                            </div>
                            <div class="elementor-ribbon elementor-ribbon-right">
                <div class="elementor-ribbon-inner">Open road</div>
            </div>
                </a>
                </div>
                </div>
            </div>
            
            
            <div class="col-lg-3">
            <div class="elementor-element elementor-element-82c41b7 elementor-cta--skin-cover elementor-cta--valign-top elementor-animated-content elementor-bg-transform elementor-bg-transform-zoom-in elementor-widget elementor-widget-call-to-action" data-id="82c41b7" data-element_type="widget" data-widget_type="call-to-action.default">
                <div class="elementor-widget-container">
                    <a class="elementor-cta" href="/supercar-track-days">
                    <div class="elementor-cta__bg-wrapper">
                <div class="elementor-cta__bg elementor-bg" style="background-image:url('https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercar-Pics-600x500-1.jpg')"></div>
                <div class="elementor-cta__bg-overlay"></div>
            </div>
                            <div class="elementor-cta__content">
                
                <h2 class="elementor-cta__title elementor-cta__content-item elementor-content-item elementor-animated-item--grow">RENTALS</h2>
                
                            </div>
                            <div class="elementor-ribbon elementor-ribbon-right">
                <div class="elementor-ribbon-inner">Rent one</div>
            </div>
                </a>
                </div>
                </div>
            </div>
            
            
            <div class="col-lg-3">
            <div class="elementor-element elementor-element-82c41b7 elementor-cta--skin-cover elementor-cta--valign-top elementor-animated-content elementor-bg-transform elementor-bg-transform-zoom-in elementor-widget elementor-widget-call-to-action" data-id="82c41b7" data-element_type="widget" data-widget_type="call-to-action.default">
                <div class="elementor-widget-container">
                    <a class="elementor-cta" href="/supercar-track-days">
                    <div class="elementor-cta__bg-wrapper">
                <div class="elementor-cta__bg elementor-bg" style="background-image:url('https://supercarexperiences.ca/wp-content/uploads/2021/11/Supercar-Pics-600x500-1.png')"></div>
                <div class="elementor-cta__bg-overlay"></div>
            </div>
                            <div class="elementor-cta__content">
                
                <h2 class="elementor-cta__title elementor-cta__content-item elementor-content-item elementor-animated-item--grow">TEST DRIVES</h2>
                
                            </div>
                            <div class="elementor-ribbon elementor-ribbon-right">
                <div class="elementor-ribbon-inner">Test One today!</div>
            </div>
                </a>
                </div>
                </div>
            </div>
            
            
        </div>
</section><section class="w-supercar">
    <!-- DATA Item code page-caption-main --><div class="section-head" style="background:black;">
<h2>RACETRACK SUPERCAR DRIVING EXPERIENCES</h2>
<p><span>Our supercars are your supercars! Pick your favorite exotics&nbsp;from the largest fleet in the world and drive them without any speed limits.</span></p>
</div>    <div id="experiences-packages-index">
        <div class="container">
            <div class="grid-d-3 grid-tl-4 grid-t-6 grid-m-12">
    <div class="b-supercar">
        <div class="over-wraper">
            <form action="https://exoticsracing.com/driving-experience" method="post" class="b-specs-rm">
                <div class="b-supercar__item">
                    <a href="driving-experience/drive-ferrari.html" class="block">
                        <figure class="text-center">
                            <div class="b-supercar__item__image-wrapper">
                                <img class="lazy b-supercar__item__image" data-original="https://d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/ferrari_f8/ferrarif8-listview.png" src="images/img-loader.gif" alt="" />                            </div>
                            <figcaption class="caption">
                                Drive a  <span class="bold-grey">Ferrari</span>                            </figcaption>
                            <p class="price text-center">
                                                                    from                                                                                                     $299  / 5 LAPS                                                            </p>
                        </figure>
                    </a>
                    <div class="controls">
                        <p class="price text-center">
                            from $45 per lap                        </p>
                        <ul class="b-ferrari__list unstyled-list">
                                                            <li class="inactive">
                                    <a href="driving-experience/drive-ferrari.html">
                                        <b>
                                            Compare all Ferraris                                        </b>
                                    </a>
                                </li>
                                                                                                                        <input type="hidden" name="model_id" id="package_id" value="1">
                                <li>
                                    <a class="block" href="driving-experience/ferrari-f430-f1.html">
                                        Ferrari F430 F1                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </li>
                                                                                            <input type="hidden" name="model_id" id="package_id" value="106">
                                <li>
                                    <a class="block" href="driving-experience/ferrari-488-gtb.html">
                                        Ferrari 488 GTB                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </li>
                                                                                            <input type="hidden" name="model_id" id="package_id" value="127">
                                <li>
                                    <a class="block" href="driving-experience/ferrari-488-pista.html">
                                        Ferrari 488 Pista                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </li>
                                                                                            <input type="hidden" name="model_id" id="package_id" value="143">
                                <li>
                                    <a class="block" href="driving-experience/ferrari-488-challenge-evo.html">
                                        Ferrari 488 Challenge Evo                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </li>
                                                    </ul>
                        <div class="w-btn">
                            <div class="container">
                                                                    <div class="grid-d-12 grid-m-12">
                                        <a class="inverblue-button" href="driving-experience/drive-ferrari.html">
                                            LEARN MORE                                        </a>
                                    </div>
                                                            </div>
                        </div>
                    </div>
                </div>
                                    <input id="track_id" type="hidden" value="1" name="track_id">
                            </form>
        </div>
    </div>
    <div class="custom-shadow"></div>
</div>
<div class="grid-d-3 grid-tl-4 grid-t-6 grid-m-12">
    <div class="b-supercar">
        <div class="over-wraper">
            <form action="https://exoticsracing.com/driving-experience" method="post" class="b-specs-rm">
                <div class="b-supercar__item">
                    <a href="driving-experience/drive-lamborghini.html" class="block">
                        <figure class="text-center">
                            <div class="b-supercar__item__image-wrapper">
                                <img class="lazy b-supercar__item__image" data-original="https://d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/listview/31.png" src="images/img-loader.gif" alt="" />                            </div>
                            <figcaption class="caption">
                                Drive a  <span class="bold-grey">Lamborghini</span>                            </figcaption>
                            <p class="price text-center">
                                                                    from                                                                                                     $299  / 5 LAPS                                                            </p>
                        </figure>
                    </a>
                    <div class="controls">
                        <p class="price text-center">
                            from $45 per lap                        </p>
                        <ul class="b-ferrari__list unstyled-list">
                                                            <li class="inactive">
                                    <a href="driving-experience/drive-lamborghini.html">
                                        <b>
                                            Compare all Lamborghinis                                        </b>
                                    </a>
                                </li>
                                                                                                                        <input type="hidden" name="model_id" id="package_id" value="4">
                                <li>
                                    <a class="block" href="driving-experience/lamborghini-gallardo-lp550.html">
                                        Lamborghini Gallardo LP550-2                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </li>
                                                                                            <input type="hidden" name="model_id" id="package_id" value="31">
                                <li>
                                    <a class="block" href="driving-experience/lamborghini-huracan-lp580-2.html">
                                        Lamborghini Huracan LP580-2                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </li>
                                                                                            <input type="hidden" name="model_id" id="package_id" value="132">
                                <li>
                                    <a class="block" href="driving-experience/lamborghini-huracan-sto.html">
                                        Lamborghini Huracan STO                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </li>
                                                                                            <input type="hidden" name="model_id" id="package_id" value="145">
                                <li>
                                    <a class="block" href="driving-experience/lamborghini-super-trofeo-evo.html">
                                        Lamborghini Huracan Super Trofeo Evo                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </li>
                                                    </ul>
                        <div class="w-btn">
                            <div class="container">
                                                                    <div class="grid-d-12 grid-m-12">
                                        <a class="inverblue-button" href="driving-experience/drive-lamborghini.html">
                                            LEARN MORE                                        </a>
                                    </div>
                                                            </div>
                        </div>
                    </div>
                </div>
                                    <input id="track_id" type="hidden" value="1" name="track_id">
                            </form>
        </div>
    </div>
    <div class="custom-shadow"></div>
</div>
<div class="grid-d-3 grid-tl-4 grid-t-6 grid-m-12">
    <div class="b-supercar">
        <div class="over-wraper">
            <form action="https://exoticsracing.com/driving-experience" method="post" class="b-specs-rm">
                <div class="b-supercar__item">
                    <a href="driving-experience/drive-porsche.html" class="block">
                        <figure class="text-center">
                            <div class="b-supercar__item__image-wrapper">
                                <img class="lazy b-supercar__item__image" data-original="https://d1i1eo6qmdfmdv.cloudfront.net/upload/site/models/porsche_992_gt3/992_GT3_listview.png" src="images/img-loader.gif" alt="" />                            </div>
                            <figcaption class="caption">
                                Drive a  <span class="bold-grey">Porsche</span>                            </figcaption>
                            <p class="price text-center">
                                                                    from                                                                                                     $199  / 5 LAPS                                                            </p>
                        </figure>
                    </a>
                    <div class="controls">
                        <p class="price text-center">
                            from $28 per lap                        </p>
                        <ul class="b-ferrari__list unstyled-list">
                                                            <li class="inactive">
                                    <a href="driving-experience/drive-porsche.html">
                                        <b>
                                            Compare all Porsches                                        </b>
                                    </a>
                                </li>
                                                                                                                        <input type="hidden" name="model_id" id="package_id" value="102">
                                <li>
                                    <a class="block" href="driving-experience/porsche-cayman-gts.html">
                                        Porsche 718 Cayman GTS                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </li>
                                                                                            <input type="hidden" name="model_id" id="package_id" value="140">
                                <li>
                                    <a class="block" href="driving-experience/porsche-cayman-gt4.html">
                                        Porsche 718 Cayman GT4                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </li>
                                                                                            <input type="hidden" name="model_id" id="package_id" value="126">
                                <li>
                                    <a class="block" href="driving-experience/porsche-992-gt3.html">
                                        Porsche 992 GT3                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </li>
                                                                                            <input type="hidden" name="model_id" id="package_id" value="125">
                                <li>
                                    <a class="block" href="driving-experience/porsche-gt2-rs.html">
                                        Porsche 991 GT2 RS                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </li>
                                                                                            <input type="hidden" name="model_id" id="package_id" value="95">
                                <li>
                                    <a class="block" href="driving-experience/porsche-911-gt3-rs-gen1.html">
                                        Porsche 991 GT3 RS                                        <i class="fa fa-angle-right"></i>
                                    </a>
                                </li>
                                                    </ul>
                        <div class="w-btn">
                            <div class="container">
                                                                    <div class="grid-d-12 grid-m-12">
                                        <a class="inverblue-button" href="driving-experience/drive-porsche.html">
                                            LEARN MORE                                        </a>
                                    </div>
                                                            </div>
                        </div>
                    </div>
                </div>
                                    <input id="track_id" type="hidden" value="1" name="track_id">
                            </form>
        </div>
    </div>
    <div class="custom-shadow"></div>
</div>     

</div>
        <div class="w-more__cars">
    <div class="b-header__sub">
        <h2 class="b-header__sub-txt">
            Is one not <b>enough?</b>        </h2>
    </div>
    <div class="container">
        <div class="text-center">
            <figure class="b-more__cars">
                <a href="driving-experience/combos.html">
                    <img class="lazy" src="themes/exotics/images/no-image.png" data-original="/themes/wp_exr/img/car_md/img11.png" alt="">
                </a>
                <figcaption>
                    Create your own multi-car package to drive up to 19 supercars and receive <strong>up to $100 off each additional car.</strong>                    <br>
                    <br>
                    <a class="inverblue-button" href="driving-experience/combos.html">
                        MULTIPLE CAR PACKAGES                    </a>
                    <a class="blue-button" href="driving-experience.html">
                        CUSTOMIZED EXPERIENCE                    </a>
                </figcaption>
            </figure><!--b-more__cars-->
        </div>
    </div>
</div><!--w-more__cars-->
        <br>
        <br>
    </div>
</section><!-- DATA Item code page-block-homepage-driving-experience --><section class="w-section design-narrow">
<div class="section-head" style="background:black;">
<h2><strong>The #1 supercar</strong> driving experience</h2>
<p>Why choose Exotic Racing, the best driving experience in America?</p>
</div>
<div class="container">
<div class="swiper-box swiper3">
<div class="swiper-container driving-experience-swiper">
<div class="swiper-wrapper">
<div class="swiper-slide">
<div>
<div class="img ico1"></div>
<b>Largest Fleet of<br />Supercars in the World</b>
<p>With a selection of Ferraris, Lamborghinis, McLarens, Porsches and many others, we offer more cars, racecars and go-karts to choose from than any other driving experience. Choosing Exotics Racing is easy. Choosing which car to drive first, not so much.</p>
</div>
</div>
<div class="swiper-slide">
<div>
<div class="img ico2"></div>
<b>Fastest and Safest<br />Racetrack</b>
<p>Our exclusive racetrack is specifically designed for our supercar driving experiences. Our safety record is the best in the industry. Large runoff areas and TecPro safety barriers match the standards set by Formula 1.</p>
</div>
</div>
<div class="swiper-slide">
<div>
<div class="img ico3"></div>
<b>The Original Supercar<br />Driving Experience</b>
<p>In 2005, we created the world&rsquo;s first&nbsp;supercar driving experience in Europe. Since then, Exotics Racing has become the number 1&nbsp;driving experience worldwide. Many have tried to copy us, but we remain the leader of the pack. Don&rsquo;t settle for less, drive the original.</p>
</div>
</div>
<div class="swiper-slide">
<div>
<div class="img ico5"></div>
<b>300,000+<br />Satisfied Clients</b>
<p>Among our competition, we are the most highly rated supercar driving experience. Our commitment to <g class="gr_ gr_50 gr-alert gr_spell gr_inline_cards gr_run_anim ContextualSpelling multiReplace" id="50" data-gr-id="50">high quality</g> service, fun and safety <g class="gr_ gr_49 gr-alert gr_gramm gr_inline_cards gr_run_anim Grammar multiReplace" id="49" data-gr-id="49">is</g> unparalleled. As a result, we&rsquo;ve won multiple Best of Las Vegas and TripAdvisor awards over the past several years.</p>
</div>
</div>
<div class="swiper-slide">
<div>
<div class="img ico6"></div>
<b>Celebrity<br />Connection</b>
<p>There is a reason why Lebron James, Michelle Rodriguez, Mario Andretti, Kyle Busch, DJ Tiesto, Jay Leno, Eli Tomac, Chuck Liddell, Caitlyn Jenner, and many more choose us as their destination of choice: there is nothing like Exotics racing!</p>
</div>
</div>
<div class="swiper-slide">
<div>
<div class="img ico8"></div>
<b>EXOTICS RACING <br />TIME TRIAL CHALLENGE</b>
<p>Take part of the world's largest motorsports competition, exclusively at Exotics Racing Las Vegas. Whether you want to race against the clock or a friend, our automatic live and online ranking allows you to compare your times and rank against other drivers.</p>
</div>
</div>
<div class="swiper-slide">
<div>
<div class="img ico8"></div>
<b>Friendly<br />Experts</b>
<p>Overseen by a team of friendly racing experts, we have the best racing instructors and racecar drivers who deliver an unrivaled driving experience in the United States of America.</p>
</div>
</div>
<div class="swiper-slide">
<div>
<div class="img ico7"></div>
<b>Motorsport<br />Destinations</b>
<p>Our exclusive racetrack is located at Speed Vegas. There&nbsp;are also the fastest go-kart track &amp; Off-Road track in Las Vegas opened 7 days a week.</p>
</div>
</div>
</div>
</div>
<div class="swiper-button-next"></div>
<div class="swiper-button-prev"></div>
</div>
</div>
</section><!-- DATA Item code page-block-homepage-galleries -->


<section class="w-gallery main" 
style="background-size: 100%!important;
    background: url('{{ asset('img/4296990.webp') }}') 0px 80%;
    background-attachment: fixed;
    padding: 0px;
    position:sticky;
    "

>
<div class="row"
style="background:#000000b8;"
>
<div class="container"  style="position:sticky;">
<div class="b-gallery text-center">
<div class="b-header">
    <div class="mt-2"style="background-image: url('{{ asset('img/Socials.png') }}');
                        background-position: center center;
                        background-repeat: no-repeat;
                        background-size: 50% auto;
                    ">

                            <h2 class=" b-header__txt text-white "
                                style="display: flex;
                            flex-wrap: nowrap;
                            justify-content: center;
                        ">
                                TRACK DAYS</h2>

                        </div>

</div>
<div class="w-text " style="">Some of the biggest names in professional sports and entertainment enjoy the rush of driving our supercars at our Las Vegas racetrack. Exotics Racing celebrity guests include international athletes, racing car drivers and Hollywood actors who want to have the most exclusive and thrilling driving experience possible. Michelle RODRIGUEZ, Zac EFRON, Jamie FOXX, DJ TIESTO, Lebron JAMES, Jay LENO, Mario ANDRETTI, Charles LECLERC, Eli TOMAC, Chuck LIDDELL, Victoria's Secret Angel Taylor HILL, Caitlyn JENNER, Scott DISICK and many more trust us!</div>
{{-- <div class="w-btn"><a class="btn-inver-white" href="media/tab/hall-of-fame.html">celebrities</a> <a class="btn-inver-white" href="media/tab/photos.html">photos</a> <a class="btn-inver-white" href="media/tab/videos.html">videos</a><a class="btn-inver-white" href="media.html">media</a></div> --}}
</div>
</div>
</div>
</section>

<section class="w-gallery main"
style="background-size: 100%!important;
    background: url(https://d2snyq93qb0udd.cloudfront.net/prod/27143_ROAD-VISORE-INTERNO-SUPERCAR-LE-AUTO-DEI-SOGNI-1910X620.jpg) 0px 80%;
    background-attachment: fixed;
    padding: 0px;"
>

<div class="row"
style="background:#000000b8;"
>
<div class="container">
<div class="b-gallery text-center">
<div class="b-header">
    <div class="mt-2"style="background-image: url('{{ asset('img/Socials.png') }}');
                        background-position: center center;
                        background-repeat: no-repeat;
                        background-size: 50% auto;
                    ">

                            <h2 class="text-white "
                                style="display: flex;
                            flex-wrap: nowrap;
                            justify-content: center;
                        ">TOUR DAYS</h2>

                        </div>

</div>
<div class="w-text "style="">Some of the biggest names in professional sports and entertainment enjoy the rush of driving our supercars at our Las Vegas racetrack. Exotics Racing celebrity guests include international athletes, racing car drivers and Hollywood actors who want to have the most exclusive and thrilling driving experience possible. Michelle RODRIGUEZ, Zac EFRON, Jamie FOXX, DJ TIESTO, Lebron JAMES, Jay LENO, Mario ANDRETTI, Charles LECLERC, Eli TOMAC, Chuck LIDDELL, Victoria's Secret Angel Taylor HILL, Caitlyn JENNER, Scott DISICK and many more trust us!</div>
{{-- <div class="w-btn"><a class="btn-inver-white" href="media/tab/hall-of-fame.html">celebrities</a> <a class="btn-inver-white" href="media/tab/photos.html">photos</a> <a class="btn-inver-white" href="media/tab/videos.html">videos</a><a class="btn-inver-white" href="media.html">media</a></div>
</div> --}}
</div>
</div>
</section>

<section class="w-gallery main"
style="background-size: 100%!important;
    background:  url('{{ asset('img/spyder1.jpg') }}') 0px 80%;
    background-attachment: fixed;
    padding: 0px;"
>

<div class="row"
style="background:#000000b8;"
>
<div class="container">
<div class="b-gallery text-center">
<div class="b-header">
    <div class="mt-2"style="background-image: url('{{ asset('img/Socials.png') }}');
                        background-position: center center;
                        background-repeat: no-repeat;
                        background-size: 50% auto;
                    ">

                            <h2 class="text-white "
                                style="display: flex;
                            flex-wrap: nowrap;
                            justify-content: center;
                        ">RENTALS</h2>

                        </div>

</div>
<div class="w-text " style="">Some of the biggest names in professional sports and entertainment enjoy the rush of driving our supercars at our Las Vegas racetrack. Exotics Racing celebrity guests include international athletes, racing car drivers and Hollywood actors who want to have the most exclusive and thrilling driving experience possible. Michelle RODRIGUEZ, Zac EFRON, Jamie FOXX, DJ TIESTO, Lebron JAMES, Jay LENO, Mario ANDRETTI, Charles LECLERC, Eli TOMAC, Chuck LIDDELL, Victoria's Secret Angel Taylor HILL, Caitlyn JENNER, Scott DISICK and many more trust us!</div>
{{-- <div class="w-btn"><a class="btn-inver-white" href="media/tab/hall-of-fame.html">celebrities</a> <a class="btn-inver-white" href="media/tab/photos.html">photos</a> <a class="btn-inver-white" href="media/tab/videos.html">videos</a><a class="btn-inver-white" href="media.html">media</a></div>
</div> --}}
</div>
</div>
</section>

<!-- DATA Item code page-block-homepage-reviews --><section class="w-reviews">
<div class="section-head">
<h2>over <strong>260,000 happy customers</strong></h2>
</div>
<div class="b-review__slider">
<div id="review-slider" class="owl-carousel">
<div class="item">
<figure><img class="ava" src="https://cdn-icons-png.flaticon.com/512/2202/2202112.png" alt="Reviews Testimonials" style="width:78px; height:78px;" width="78" height="78" /> <figcaption>
<div class="name">Ashley from Austin, Texas</div>
<div class="review">&laquo; Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam a pulvinar ex. Curabitur at libero ligula. Sed nec felis elit. Vivamus tincidunt ultrices mi quis elementum. </div>
<div class="b-rate rating4"></div>
</figcaption></figure>
</div>
<div class="item">
<figure><img class="ava" src="https://cdn-icons-png.flaticon.com/512/2202/2202112.png" alt="Reviews Testimonials" style="width:78px; height:78px;" width="78" height="78" /> <figcaption>
<div class="name">Rodrigo from Sao Paulo, Brazil</div>
<div class="review">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam a pulvinar ex. Curabitur at libero ligula. Sed nec felis elit. Vivamus tincidunt ultrices mi quis elementum. </div>
<div class="b-rate rating4"></div>
</figcaption></figure>
</div>
<div class="item">
<figure><img class="ava" src="https://cdn-icons-png.flaticon.com/512/2202/2202112.png" alt="Reviews Testimonials" style="width:78px; height:78px;" width="78" height="78" /> <figcaption>
<div class="name">Olivier from Paris, France</div>
<div class="review">&laquo; Super stage de pilotage sur un circuit incroyable! J&rsquo;ai conduit la nouvelle Mc Laren et mon coach &eacute;tait tr&egrave;s pro, en me donnant des vrais conseils pour piloter sur circuit. Je conseille cette exp&eacute;rience a tous ceux qui passent par Vegas, vous ne vivrez ca nulle part ailleurs! &raquo;</div>
<div class="b-rate rating4"></div>
</figcaption></figure>
</div>
<div class="item">
<figure><img class="ava" src="https://cdn-icons-png.flaticon.com/512/2202/2202112.png" alt="Reviews Testimonials" style="width:78px; height:78px;" width="78" height="78" /> <figcaption>
<div class="name">Jose from Guadalajara, Mexico</div>
<div class="review">&laquo; Toda la experiencia fue impecable de principio a fin . El ambiente es muy alegre, y todos son muy amable. Pero tengo que decir que lo que mas disfrute fue cuando me subi con el instructor en el Corvette. Estar&eacute; de vuelta pronto. Gracias! &raquo;</div>
<div class="b-rate rating4"></div>
</figcaption></figure>
</div>
</div>
</div>{{-- 
<a class="inverblue-button padding50" href="reviews.html">VIEW ALL 7,760 TESTIMONIALS</a> --}}
<div id="video" class="b-video no-video"><img src="https://images.unsplash.com/photo-1552255440-ac1fa0a5b2a3?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=464&q=80" alt="" class="b-video__img img-responsive" />
    <iframe width="683" height="432" style="border: none;" src="https://www.youtube.com/embed/2N_PCsUDxdA"></iframe></div>
</section><section class="w-news ">
    <!-- DATA Item code page-block-caption-latest-news -->
    <div class="section-head" style="background:black;">
<h2>latest news</h2>
<p>Stay in touch with everything that's happening at Exotics Racing</p>
</div>    
<div class="container">
        <div class="b-news__container pull-left">
            <div class="col">
    <div class="b-social__head"><i class="icon icon-instagram"></i> Follow us on instagram</div>
    <!--b-social__head-->
    <div class="b-instargam">
        <div class="tab-aggregator">
            <div class="item-list">
                <div class="items" id="instafeed"></div>
            </div>
        </div>
    </div>
</div>            <div class="b-social__head">Latest News</div>
            <div class="tab-aggregator">
    <div class="item-list">
        <div class="item ">
    <div>
        EXOTICS RACING AND SPEEDVEGAS JOIN FORCES TO BECOME SPEEDVEGAS MOTORSPORTS PARK NOVEMBER 29TH    </div>
    <div class="image-background-wrapper">
        <a href="news/exotics-racing-and-speed-vegas-join-forces.html" data-original="https://d1i1eo6qmdfmdv.cloudfront.net/upload/news/61940424aa46a_webside_news.jpg" style="" class="img image-background read-more lazy "></a>
        <div class="image-background-spinner"></div>
    </div>
    <span>
        Nov 16 2021    </span>
    <div class="w-text">
        Beginning Nov. 29th, Exotics Racing’s elite supercar driving experience will join forces with SPEEDVEGAS...    </div>
    <br>
    <br>
    <a href="news/exotics-racing-and-speed-vegas-join-forces.html" class="blue-button read-more">READ MORE</a>
    <br>
    <br>
</div>
<div class="item ">
    <div>
        THE RAIDERS VISIT EXOTICS RACING    </div>
    <div class="image-background-wrapper">
        <a href="news/The_Raiders_Visit_Exotics_Racing.html" data-original="https://d1i1eo6qmdfmdv.cloudfront.net/upload/news/5ffc301d2817b_raiders.jpg" style="" class="img image-background read-more lazy "></a>
        <div class="image-background-spinner"></div>
    </div>
    <span>
        Jan 11 2021    </span>
    <div class="w-text">
        Celebrities love Exotics Racing as much as anybody else, maybe even more!    </div>
    <br>
    <br>
    <a href="news/The_Raiders_Visit_Exotics_Racing.html" class="blue-button read-more">READ MORE</a>
    <br>
    <br>
</div>
    </div> 
</div>        </div>
        <div class="b-social__container pull-right">
            <div id="fb-last-posts"></div>
<hr>
<div class="col">
    <div class="b-social__head"><i class="icon icon-twitter"></i> Follow us on twitter</div>
    <div class="b-twitter">
        <a class="twitter-timeline" href="https://twitter.com/ExoticsRacing" data-widget-id="423265429562212352" data-chrome="noheader nofooter noborders">Tweets by @ExoticsRacing</a>
        <script>// <![CDATA[
            !function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="../platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
            // ]]></script>
    </div>
</div>

        </div>
    </div>
</section><!-- DATA Item code page-block-homepage-stats -->
<section class="w-stats" style="background:black;">
<div class="container">
<div class="b-stats">
<div class="item">
<div class="icon icon-satsifiedcustomers"></div>
<span class="counter">400,000</span>
<p class="caption">Satisfied Customers</p>
</div>
<div class="item">
<div class="icon icon-supercars"></div>
<span class="counter">30</span>
<p class="caption">Supercars</p>
</div>
<div class="item">
<div class="icon icon-employees"></div>
<span class="counter">80</span>
<p class="caption">Employees</p>
</div>
</div>
</div>
</section>    </section>
                        <script>
                $(function () {
                    $('.summary-panel .top .close').on('click', function (event) {
                        event.preventDefault();
                        $('.summary-panel').hide();
                    });
                    var movedFlag = false;
                    var panel = $('.summary-panel');
                    var screenW = $(document).width();
                    $('.summary-panel .top').on('mousedown', function (event) {
                        movedFlag = true;
                    });
                    $("body").on('mousemove', function (event) {
                        var cursorX = event.pageX,
                            cursorY = event.pageY;
                        if (movedFlag) {
                            panel.css({top: cursorY - 45 + 'px', right: screenW - cursorX - 145 + 'px'});
                        }
                    }).on('mouseup', function () {
                        movedFlag = false;
                    });
                });
            </script>
            <div class="block-layer">
                <img src="img/loader.svg" alt="">
            </div>
        </main>
        <footer  style="
        background-size: 100%!important;
        background:url('https://supercarexperiences.ca/wp-content/uploads/2021/05/2.jpg') 0px 80%;
        background-attachment:fixed;
        padding:0px;
        ">
        <div class="row" style="background:#fffffff0;">
            <!-- DATA Item code menu-footer -->
            <div class="container">
<div class="row-fluid footer-help" style="color:black;">
<div class="span3">
<figure class="item"><i style="color:black;" class="ico1"></i> <figcaption style="color:black;"> secured <br /> online payment</figcaption></figure>
</div>
<div class="span3">
<figure class="item"><i style="color:black;" class="ico2"></i> <figcaption style="color:black;">expert <br />instructors</figcaption></figure>
</div>
<div class="span3">
<figure class="item"><i style="color:black;" class="ico3"></i> <figcaption style="color:black;"> need help?
<p>Contact our customer service</p>
</figcaption></figure>
</div>
<div class="span3">
<figure style="color:black;" class="item"><i style="color:black;" class="ico4"></i> <i style="color:black;" class="ico5"></i> <i style="color:black;" class="ico6"></i> <figcaption> approved <br />and certified </figcaption></figure>
</div>
</div>
<!--footer-help-->
<div class="search-panel" style="background:black;">
<div class="row-fluid">
<div class="span6"><form id="searchForm" method="post" action="https://exoticsracing.com/search" class="search-site">
<table>
<tbody>
<tr>
<td>
<div class="form-group"><i class="icon-search"></i> <input placeholder="Search site" type="text" /></div>
</td>
<td><button type="submit" style="background:white;; color:black" class="b-btn__book styled block"> <span style="color:black;" class="text">SEARCH</span></button></td>
</tr>
</tbody>
</table>
</form></div>
<div class="span6"><form class="newsletter-form">
    <table>
        <tr>
            <td>
                <label style="color:white;" for="inputAddNewsletterEmail">
                    Newsletter
                </label>
            </td>
            <td>
                <div class="form-group">
                    <input id="inputAddNewsletterEmail" type="text" placeholder="Your Email">
                    <button type="submit" id="btnAddNewsletterEmail">
                        OK
                    </button>
                </div>
            </td>
        </tr>
        <tr>
            <td>
                <div id="addNewsletterEmailLoading" style="display: none;">
                    <img src="themes/wp_exr/images/loading_16x16.gif" width="16" height="16">
                </div>
            </td>
            <td>
                <div id="messageAddNewsletterEmail"></div>
            </td>
        </tr>
    </table>
</form></div>
</div>
</div>
<!--search-panel-->
<div class="footer-menu">
<div class="container" style="margin-left:80px;">
<div>
<ul >
<li class="title">Main</li>
<li><a href="index.html">Back to Home</a></li>
<li><a href="driving-experience.html">Customize Your Experience</a></li>
<li><a href="driving-experience.html">Exotics Driving Experience</a></li>
<li><a href="driving-experience/combos.html">Multiple Car Packages</a></li>
<li><a href="driving-experience/drifting-supercar-ride-along-experience.html">Supercar Ride-Along</a></li>
<li><a href="driving-experience/vip-experience.html">VIP Experiences</a></li>
<li><a href="driving-experience/speed-vegas-motorsport-park/gift-certificate.html">Gift Packages</a></li>
<li><a href="group-corporate-events.html">Group Events</a></li>
<li><a href="las-vegas-bachelor-party.html">Bachelor Party Vegas</a></li>
</ul>
</div>
<div>
<ul>
<li class="title">Driving Experiences</li>
<li><a href="driving-experience/drive-ferrari.html">Drive a Ferrari</a></li>
<li><a href="driving-experience/drive-lamborghini.html">Drive a Lamborghini</a></li>
<li><a href="driving-experience/drive-porsche.html">Drive a Porsche</a></li>
<li><a href="driving-experience/mclaren-gt4.html">Drive a McLaren</a></li>
<li><a href="driving-experience/audi-r8-v10-plus.html">Drive an Audi R8</a></li>
<li><a href="driving-experience/shelby-gt500.html">Drive a Mustang</a></li>
<li><a href="driving-experience/nissan-gt-r.html">Drive a Nissan GT-R</a></li>
<li><a href="driving-experience/mercedes-benz-amg-gtr.html">Drive a Mercedes AMG</a></li>
<li><a href="driving-experience/drive-corvette.html">Drive a Corvette</a></li>
<li><a href="driving-experience/acura-nsx.html">Drive an Acura NSX</a></li>
<li><a href="go-kart/arrive-and-drive.html">Drive a Go-Kart</a></li>
</ul>
</div>
<div><!--ul>
<li class="title">Tours</li>
<li><a href="/tour/los-angeles-supercar-tour">Los Angeles Supercar Tour</a></li>
<li><a href="/tour/los-angeles/gift-certificate">Gift Certificates</a></li>
<li><a href="/tour/los-angeles/hours-directions">Hours &amp; Directions</a></li>
<li><a href="/site/faq#6">FAQs</a></li>
</ul-->
<ul>
<li class="title">Redeme Gifts</li>
<li><a href="go-kart/arrive-and-drive.html">Arrive and Drive</a></li>
<li><a href="go-kart/vsk-championship.html">Join our Championship</a></li>
<li><a href="go-kart/group-events.html">Parties &amp; Groups</a></li>
<li><a href="go-kart/group-events.html">Corporate Events</a></li>
<li><a href="go-kart/hours-directions.html">Hours &amp; Directions</a></li>
<li><a href="go-kart/gift-certificate.html">Gift Certificates</a></li>
</ul>

</div>

<!-- <div>
<ul>
<li class="title">About us</li>
<li><a href="faqs.html">Faqs</a></li>
<li><a href="about-us.html">About Exotics Racing</a></li>
<li><a href="exotic-cars.html">Our Exotic Cars</a></li>
<li><a href="reviews.html">Reviews</a></li>
<li><a href="media/tab/photos.html">Photos</a></li>
<li><a href="media/tab/videos.html">Videos</a></li>
<li><a href="media/tab/hall-of-fame.html">Celebrities</a></li>
<li><a href="media/tab/press.html">Media</a></li>
<li><a href="careers.html">Careers</a></li>
<li><a href="contact-us.html">Contact Us</a></li>
</ul>
<ul>
<li class="title">My Account</li>
<li><a href="user/login.html">Account Login</a></li>
<li><a href="user/login.html">User Information</a></li>
<li><a href="driving-experience.html">Book Now</a></li>
<li><a href="faqs.html">Faqs</a></li>
<li><a href="contact-us.html">Contact Us</a></li>
</ul>
</div> -->
</div>
</div>
</div>            <!-- DATA Item code footer-partners -->

<div class="partners">
<div class="container">

     <!-- <a href="http://www.hexis-graphics.com/us/" target="_blank" rel="nofollow" class="item"><span class="hexis"></span>&nbsp;</a>  -->
     
    </div>
</div>            <div class="copy text-center">
                <div><a href="sitemap.html">Site map</a> | <a href="terms.html">Terms of use</a></div>
                <div>&copy; 2022 . All rights reserved Super Car Experiences</div>
            </div><!--Copy-->
            <script async type="text/javascript">
                var bcLoad = function () {
                    if (window.bcLoaded) return;
                    window.bcLoaded = true;
                    var vms = document.createElement("script");
                    vms.type = "text/javascript";
                    vms.async = true;
                    vms.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + "vmss.boldchat.com/aid/882446050031162689/bc.vms4/vms.js";
                    var s = document.getElementsByTagName('script')[0];
                    s.parentNode.insertBefore(vms, s);
                };
                if (window.pageViewer && pageViewer.load) pageViewer.load();
                else if (document.readyState == "complete") bcLoad();
                else if (window.addEventListener) window.addEventListener('load', bcLoad, false);
                else window.attachEvent('onload', bcLoad);
            </script>
            </div>
        </footer>
        <a href="#" class="b-top block">
            <i class="icon icon-backtotop"></i>
            <div class="text">Back
                <small>to top</small>
            </div>
        </a>
                    <style>.et_bloom .et_bloom_optin_0 .et_bloom_form_content { background-color: #333333 !important; } .et_bloom .et_bloom_optin_0 .et_bloom_form_container .et_bloom_form_header { background-color: #dfdfdf !important; } .et_bloom .et_bloom_optin_0 .curve_edge .curve { fill: #dfdfdf} .et_bloom .et_bloom_optin_0 .et_bloom_form_content button { background-color: #ee0000 !important; } .et_bloom .et_bloom_optin_0 .et_bloom_border_solid { border-color: #000000 !important } .et_bloom .et_bloom_optin_0 .et_bloom_form_content button { background-color: #ee0000 !important; } .et_bloom .et_bloom_optin_0 .et_bloom_form_text h2 {font-family: "titillium_webregular", Arial; font-size: 2.3em !important; } </style><div class="et_bloom_popup et_bloom_optin et_bloom_optin_0 et_bloom_resize  et_bloom_auto_popup"  data-delay="85" data-cookie_duration="30">
    <div class="et_bloom_form_container et_bloom_popup_container  with_edge curve_edge et_bloom_with_border et_bloom_border_solid et_bloom_border_position_full et_bloom_form_text_light et_bloom_form_text_light et_bloom_form_text_light et_bloom_animation_zoomin">
        <div class="et_bloom_form_container_wrapper clearfix">
            <div class="et_bloom_header_outer">
                <div class="et_bloom_form_header split  et_bloom_header_text_ dark">
                    <img src="../d1i1eo6qmdfmdv.cloudfront.net/upload/site/images/subscription/premade-image-05.png" alt="Subscribe To Our Newsletter" class=" et_bloom_image_flipinx et_bloom_image">
                    <div class="et_bloom_form_text">
                        <!-- DATA Item code subscription-block-header --><h2>Subscribe To Our Newsletter</h2>
<p>Join our mailing list to receive up to date information on upcoming races, special offers, events and news from our team!</p>                    </div>
                </div>
            </div>
            <div class="et_bloom_form_content et_bloom_1_field et_bloom_bottom_inline et_bloom_custom_html_form" data-account="custom_form" data-optin_id="optin_0" data-service="custom_form" data-list_id="custom_form" data-page_id="-1">
                                <form method="post" class="clearfix">
                    <p class="et_bloom_popup_input et_bloom_subscribe_email">
                        <input placeholder="Email" maxlength="50">
                    </p>
                    <button class="et_bloom_submit_subscription" data-optin_id="optin_0">
                        <span class="et_bloom_subscribe_loader"></span>
                        <span class="et_bloom_button_text et_bloom_button_text_color_light">
                            <!-- DATA Item code subscription-block-cta --><p>SUBSCRIBE NOW!</p>                        </span>
                    </button>
                </form>
                <div class="et_bloom_success_container">
                    <span class="et_bloom_success_checkmark"></span>
                </div>

                <h2 class="et_bloom_success_message">
                    <!-- DATA Item code subscription-block-successfully-registered --><p>You have Successfully Subscribed!</p>                </h2>
            </div>
        </div>
        <span class="et_bloom_close_button"></span>
    </div>
</div>                <!-- Start Google Retargueting -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 989588192 ;
var google_conversion_label = "vrPWCMiK_wQQ4NXv1wM";
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="../www.googleadservices.com/pagead/f.txt">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="http://googleads.g.doubleclick.net/pagead/viewthroughconversion/989588192/?value=0&amp;label=vrPWCMiK_wQQ4NXv1wM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
<!-- End Google Retargueting -->
<!-- Start Hotjar -->
<script>
    (function(h,o,t,j,a,r){
        h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
        h._hjSettings={hjid:93215,hjsv:5};
        a=o.getElementsByTagName('head')[0];
        r=o.createElement('script');r.async=1;
        r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
        a.appendChild(r);
    })(window,document,'//static.hotjar.com/c/hotjar-','.js?sv=');
</script>
<!-- End Hotjar  -->
<!-- Start Rakuten Retargueting -->
<script type="text/javascript" src="http://tags.mediaforge.com/js/3286"></script>
<!-- End Rakuten Retargueting -->
<!-- Start of LiveChat (www.livechatinc.com) code -->

<noscript><a href="https://www.livechatinc.com/chat-with/13334757/" rel="nofollow">Chat with us</a>, powered by <a href="https://www.livechatinc.com/?welcome" rel="noopener nofollow" target="_blank">LiveChat</a></noscript>
<!-- End of LiveChat code --><!-- Start Google Analytics -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-962754-2', 'auto')
        ga('create', 'UA-130959389-1', 'auto', {'name' : 'm', 'domainName' : 'none',  'allowLinker': true});
        ga('m.require', 'linker');
        ga('m.linker:autoLink', ['vegassupercars.com']);
ga('send', 'pageview'); ga('m.send', 'pageview');
</script>
<!-- End Google Analytics -->
<!-- AddRoll -->
<script type="text/javascript">
    adroll_adv_id = "4TP55J54VZFPLEUHECUHUC";
    adroll_pix_id = "4RX6RQDQJ5D2DCMNIBCDWS";
    (function () {
        var _onload = function(){
            if (document.readyState && !/loaded|complete/.test(document.readyState)){setTimeout(_onload, 10);return}
            if (!window.__adroll_loaded){__adroll_loaded=true;setTimeout(_onload, 50);return}
            var scr = document.createElement("script");
            var host = (("https:" == document.location.protocol) ? "https://s.adroll.com" : "http://a.adroll.com");
            scr.setAttribute('async', 'true');
            scr.type = "text/javascript";
            scr.src = host + "/j/roundtrip.js";
            ((document.getElementsByTagName('head') || [null])[0] ||
                document.getElementsByTagName('script')[0].parentNode).appendChild(scr);
        };
        if (window.addEventListener) {window.addEventListener('load', _onload, false);}
        else {window.attachEvent('onload', _onload)}
    }());
    </script>
<!-- /AddRoll -->
<!-- Start Quantcast Tag -->
<script type="text/javascript">
var _qevents = _qevents || [];
 (function() {
   var elem = document.createElement('script');
   elem.src = (document.location.protocol == "https:" ? "https://secure" : "http://edge") + ".quantserve.com/quant.js";
   elem.async = true;
   elem.type = "text/javascript";
   var scpt = document.getElementsByTagName('script')[0];
   scpt.parentNode.insertBefore(elem, scpt);
  })();
_qevents.push({qacct: "p-gW27Kw8AMYE46"});
</script>
<noscript>
 <img src="../pixel.quantserve.com/pixel/p-gW27Kw8AMYE469476.gif?labels=_fp.event.Default" style="display: none;" border="0" height="1" width="1" alt="Quantcast"/>
</noscript>
<!-- End Quantcast tag --><!-- Start of HubSpot Embed Code -->
<script type="text/javascript" id="hs-script-loader" async defer src="../js.hs-scripts.com/3951982.json"></script>
<!-- End of HubSpot Embed Code --><script data-obct type="text/javascript">
/** DO NOT MODIFY THIS CODE**/
!function(_window, _document) {
var OB_ADV_ID='00b896a30e1d2220993ab73ef443de899a';
if (_window.obApi) {var toArray = function(object)
{return Object.prototype.toString.call(object) === '[object Array]' ? object : [object];}

;_window.obApi.marketerId = toArray(_window.obApi.marketerId).concat(toArray(OB_ADV_ID));return;}
var api = _window.obApi = function()
{api.dispatch ? api.dispatch.apply(api, arguments) : api.queue.push(arguments);}

;api.version = '1.1';api.loaded = true;api.marketerId = OB_ADV_ID;api.queue = [];var tag = _document.createElement('script');tag.async = true;tag.src = '../amplify.outbrain.com/cp/obtp.js';tag.type = 'text/javascript';var script = _document.getElementsByTagName('script')[0];script.parentNode.insertBefore(tag, script);}(window, document);
obApi('track', 'PAGE_VIEW');
</script><!-- Start Criteo Homepage tag -->
<script type="text/javascript" src="../static.criteo.net/js/ld/ld.js" async="true"></script> <script type="text/javascript">
window.criteo_q = window.criteo_q || [];
var deviceType = /Mobile|iP(hone|od)|Android|BlackBerry|IEMobile|Silk/.test(navigator.userAgent) ?

"m" : /iPad/.test(navigator.userAgent) ? "t" : "d"; window.criteo_q.push(
{ event: "setAccount", account: 21898},
{ event: "setSiteType", type: deviceType},
{ event: "setHashedEmail", email: [""]},
{ event: "viewHome"});
</script>
<!-- End Criteo Homepage tag -->
    <script type="text/javascript" src="assets/2343043f/js/bootstrap.bootbox.min1b4e.js?m=1536737766"></script>
<script type="text/javascript" src="assets/2343043f/js/bootstrap.minb0c7.js?m=1536737781"></script>
<script type="text/javascript" src="assets/c26d3fd7/js/es5-shim.min26d3.js?m=1536327699"></script>
<script type="text/javascript" src="assets/1c325eb8/js/instafeedv2.min8cdb.js?m=1596188684"></script>
<script type="text/javascript" src="assets/ca65e889/js/owl.carousela9e0.js?m=1536327774"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.4.2/js/swiper.jquery.minba8c.js?m=1661370796"></script>
<script type="text/javascript" src="libs/fancybox/jquery.fancybox.minefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/libs/bootstrap-datepicker/dist/js/bootstrap-datepicker.minefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/libs/superfish/dist/js/superfish.minefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/libs/waypoints/lib/jquery.waypoints.minefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/libs/counter-up/jquery.counterupefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/libs/youtube-background/src/jquery.youtubebackgroundefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/js/jquery.readyLoadefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/js/lazy.load.minefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/js/sweetalert2.all.minefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/js/mainefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/js/facebook_trackingefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/js/jquery.visible.minefa0.js?m=1661331896"></script>
<script type="text/javascript" src="libs/cookie/jquery.cookieefa0.js?m=1661331896"></script>
<script type="text/javascript" src="assets/c94e2d0d/summary6eee.js?m=1574410013"></script>
<script type="text/javascript" src="assets/1ce650c5/js/subscribeemailbe9e.js?m=1536327700"></script>
<script type="text/javascript" src="assets/9fcfe31/js/jquery.uniform.min528a.js?m=1536327706"></script>
<script type="text/javascript" src="assets/9fcfe31/js/custom528a.js?m=1536327706"></script>
<script type="text/javascript" src="assets/9fcfe31/js/idle-timer.min528a.js?m=1536327706"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">


</body>

<!-- Mirrored from exoticsracing.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Aug 2022 09:10:03 GMT -->
</html>