@include('template.head')
@include('template.navbar')

@yield('content')
@include('template.footer')
@include('template.script')
