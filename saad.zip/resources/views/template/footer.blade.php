<footer
    style="
    background-size: 100%!important;
    background:url('https://supercarexperiences.ca/wp-content/uploads/2021/05/2.jpg') 0px 80%;
    background-attachment:fixed;
    padding:0px;
    ">
    <div class="row" style="background:#ffffffde;">
        <!-- DATA Item code menu-footer -->
        <div class="container">
            <div class="row-fluid footer-help" style="color:black;">
                <div class="span3">
                    <figure class="item">
                        <i style="color:black;" class="ico1"></i>
                        <figcaption style="color:black;"> secured <br /> online payment</figcaption>
                    </figure>
                </div>
                <div class="span3">
                    <figure class="item">
                        <i style="color:black;" class="ico2"></i>
                        <figcaption style="color:black;">expert <br />instructors</figcaption>
                    </figure>
                </div>
                <div class="span3">
                    <figure class="item">
                        <i style="color:black;" class="ico3"></i>
                        <figcaption style="color:black;">
                            need help?
                            <p>Contact our customer service</p>
                        </figcaption>
                    </figure>
                </div>
                <div class="span3">
                    <figure style="color:black;" class="item">
                        <i style="color:black;" class="ico4"></i> <i style="color:black;" class="ico5"></i> <i
                            style="color:black;" class="ico6"></i>
                        <figcaption> approved <br />and certified </figcaption>
                    </figure>
                </div>
            </div>
            <!--footer-help-->
            <div class="search-panel" style="background:black;">
                <div class="row-fluid">
                    <div class="span6">
                        <form id="searchForm" method="post" action="https://exoticsracing.com/search"
                            class="search-site">
                            <table>
                                <tbody>
                                    <tr>
                                        <td>
                                            <div class="form-group"><i class="icon-search"></i> <input
                                                    placeholder="Search site" type="text" /></div>
                                        </td>
                                        <td><button type="submit" style="background:white;; color:black"
                                                class="b-btn__book styled block"> <span style="color:black;"
                                                    class="text">SEARCH</span></button></td>
                                    </tr>
                                </tbody>
                            </table>
                        </form>
                    </div>
                    <div class="span6">
                        <form class="newsletter-form">
                            <table>
                                <tr>
                                    <td>
                                        <label style="color:white;" for="inputAddNewsletterEmail">
                                            Newsletter
                                        </label>
                                    </td>
                                    <td>
                                        <div class="form-group">
                                            <input id="inputAddNewsletterEmail" type="text" placeholder="Your Email">
                                            <button type="submit" id="btnAddNewsletterEmail">
                                                OK
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div id="addNewsletterEmailLoading" style="display: none;">
                                            <img src="themes/wp_exr/images/loading_16x16.gif" width="16"
                                                height="16">
                                        </div>
                                    </td>
                                    <td>
                                        <div id="messageAddNewsletterEmail"></div>
                                    </td>
                                </tr>
                            </table>
                        </form>
                    </div>
                </div>
            </div>
            <!--search-panel-->
            <div class="footer-menu">
                <div class="container" style="margin-left:80px;">
                    <div>
                        <ul>
                            <li class="title">Main</li>
                            <li><a href="index.html">Back to Home</a></li>
                            <li><a href="driving-experience.html">Customize Your Experience</a></li>
                            <li><a href="driving-experience.html">Exotics Driving Experience</a></li>
                            <li><a href="driving-experience/combos.html">Multiple Car Packages</a></li>
                            <li><a href="driving-experience/drifting-supercar-ride-along-experience.html">Supercar
                                    Ride-Along</a></li>
                            <li><a href="driving-experience/vip-experience.html">VIP Experiences</a></li>
                            <li><a href="driving-experience/speed-vegas-motorsport-park/gift-certificate.html">Gift
                                    Packages</a></li>
                            <li><a href="group-corporate-events.html">Group Events</a></li>
                            <li><a href="las-vegas-bachelor-party.html">Bachelor Party Vegas</a></li>
                        </ul>
                    </div>
                    <div>
                        <ul>
                            <li class="title">Driving Experiences</li>
                            <li><a href="driving-experience/drive-ferrari.html">Drive a Ferrari</a></li>
                            <li><a href="driving-experience/drive-lamborghini.html">Drive a Lamborghini</a></li>
                            <li><a href="driving-experience/drive-porsche.html">Drive a Porsche</a></li>
                            <li><a href="driving-experience/mclaren-gt4.html">Drive a McLaren</a></li>
                            <li><a href="driving-experience/audi-r8-v10-plus.html">Drive an Audi R8</a></li>
                            <li><a href="driving-experience/shelby-gt500.html">Drive a Mustang</a></li>
                            <li><a href="driving-experience/nissan-gt-r.html">Drive a Nissan GT-R</a></li>
                            <li><a href="driving-experience/mercedes-benz-amg-gtr.html">Drive a Mercedes AMG</a></li>
                            <li><a href="driving-experience/drive-corvette.html">Drive a Corvette</a></li>
                            <li><a href="driving-experience/acura-nsx.html">Drive an Acura NSX</a></li>
                            <li><a href="go-kart/arrive-and-drive.html">Drive a Go-Kart</a></li>
                        </ul>
                    </div>
                    <div>
                        <!--ul>
                <li class="title">Tours</li>
                <li><a href="/tour/los-angeles-supercar-tour">Los Angeles Supercar Tour</a></li>
                <li><a href="/tour/los-angeles/gift-certificate">Gift Certificates</a></li>
                <li><a href="/tour/los-angeles/hours-directions">Hours &amp; Directions</a></li>
                <li><a href="/site/faq#6">FAQs</a></li>
                </ul-->
                        <ul>
                            <li class="title">Redeme Gifts</li>
                            <li><a href="go-kart/arrive-and-drive.html">Arrive and Drive</a></li>
                            <li><a href="go-kart/vsk-championship.html">Join our Championship</a></li>
                            <li><a href="go-kart/group-events.html">Parties &amp; Groups</a></li>
                            <li><a href="go-kart/group-events.html">Corporate Events</a></li>
                            <li><a href="go-kart/hours-directions.html">Hours &amp; Directions</a></li>
                            <li><a href="go-kart/gift-certificate.html">Gift Certificates</a></li>
                        </ul>
                    </div>
                    <!-- <div>
              <ul>
              <li class="title">About us</li>
              <li><a href="faqs.html">Faqs</a></li>
              <li><a href="about-us.html">About Exotics Racing</a></li>
              <li><a href="exotic-cars.html">Our Exotic Cars</a></li>
              <li><a href="reviews.html">Reviews</a></li>
              <li><a href="media/tab/photos.html">Photos</a></li>
              <li><a href="media/tab/videos.html">Videos</a></li>
              <li><a href="media/tab/hall-of-fame.html">Celebrities</a></li>
              <li><a href="media/tab/press.html">Media</a></li>
              <li><a href="careers.html">Careers</a></li>
              <li><a href="contact-us.html">Contact Us</a></li>
              </ul>
              <ul>
              <li class="title">My Account</li>
              <li><a href="user/login.html">Account Login</a></li>
              <li><a href="user/login.html">User Information</a></li>
              <li><a href="driving-experience.html">Book Now</a></li>
              <li><a href="faqs.html">Faqs</a></li>
              <li><a href="contact-us.html">Contact Us</a></li>
              </ul>
              </div> -->
                </div>
            </div>
        </div>
        <!-- DATA Item code footer-partners -->
        <div class="partners">
            <div class="container">
                <!-- <a href="http://www.hexis-graphics.com/us/" target="_blank" rel="nofollow" class="item"><span class="hexis"></span>&nbsp;</a>  -->
            </div>
        </div>
        <div class="copy text-center">
            <div><a href="sitemap.html">Site map</a> | <a href="terms.html">Terms of use</a></div>
            <div>&copy; 2022 . All rights reserved Super Car Experiences</div>
        </div>
        <!--Copy-->
        <script async type="text/javascript">
            var bcLoad = function() {
                if (window.bcLoaded) return;
                window.bcLoaded = true;
                var vms = document.createElement("script");
                vms.type = "text/javascript";
                vms.async = true;
                vms.src = ('https:' == document.location.protocol ? 'https://' : 'http://') +
                    "vmss.boldchat.com/aid/882446050031162689/bc.vms4/vms.js";
                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(vms, s);
            };
            if (window.pageViewer && pageViewer.load) pageViewer.load();
            else if (document.readyState == "complete") bcLoad();
            else if (window.addEventListener) window.addEventListener('load', bcLoad, false);
            else window.attachEvent('onload', bcLoad);
        </script>
    </div>
</footer>
