<!-- Start Google Retargueting -->
<script type="text/javascript">
    /* <![CDATA[ */
    var google_conversion_id = 989588192;
    var google_conversion_label = "vrPWCMiK_wQQ4NXv1wM";
    var google_custom_params = window.google_tag_params;
    var google_remarketing_only = true;
    /* ]]> */
</script>
<script type="text/javascript" src="../www.googleadservices.com/pagead/f.txt"></script>
<noscript>
    <div style="display:inline;">
        <img height="1" width="1" style="border-style:none;" alt=""
            src="http://googleads.g.doubleclick.net/pagead/viewthroughconversion/989588192/?value=0&amp;label=vrPWCMiK_wQQ4NXv1wM&amp;guid=ON&amp;script=0" />
    </div>
</noscript>
<!-- End Google Retargueting -->
<!-- Start Hotjar -->
<script>
    (function(h, o, t, j, a, r) {
        h.hj = h.hj || function() {
            (h.hj.q = h.hj.q || []).push(arguments)
        };
        h._hjSettings = {
            hjid: 93215,
            hjsv: 5
        };
        a = o.getElementsByTagName('head')[0];
        r = o.createElement('script');
        r.async = 1;
        r.src = t + h._hjSettings.hjid + j + h._hjSettings.hjsv;
        a.appendChild(r);
    })(window, document, '//static.hotjar.com/c/hotjar-', '.js?sv=');
</script>
<!-- End Hotjar  -->
<!-- Start Rakuten Retargueting -->
<script type="text/javascript" src="http://tags.mediaforge.com/js/3286"></script>
<!-- End Rakuten Retargueting -->
<!-- Start of LiveChat (www.livechatinc.com) code -->
<noscript><a href="https://www.livechatinc.com/chat-with/13334757/" rel="nofollow">Chat with us</a>, powered
    by <a href="https://www.livechatinc.com/?welcome" rel="noopener nofollow" target="_blank">LiveChat</a></noscript>
<!-- End of LiveChat code -->
<!-- Start Google Analytics -->
<script>
    (function(i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function() {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o),
            m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', '../www.google-analytics.com/analytics.js', 'ga');
    ga('create', 'UA-962754-2', 'auto')
    ga('create', 'UA-130959389-1', 'auto', {
        'name': 'm',
        'domainName': 'none',
        'allowLinker': true
    });
    ga('m.require', 'linker');
    ga('m.linker:autoLink', ['vegassupercars.com']);
    ga('send', 'pageview');
    ga('m.send', 'pageview');
</script>
<!-- End Google Analytics -->
<!-- AddRoll -->
<script type="text/javascript">
    adroll_adv_id = "4TP55J54VZFPLEUHECUHUC";
    adroll_pix_id = "4RX6RQDQJ5D2DCMNIBCDWS";
    (function() {
        var _onload = function() {
            if (document.readyState && !/loaded|complete/.test(document.readyState)) {
                setTimeout(_onload, 10);
                return
            }
            if (!window.__adroll_loaded) {
                __adroll_loaded = true;
                setTimeout(_onload, 50);
                return
            }
            var scr = document.createElement("script");
            var host = (("https:" == document.location.protocol) ? "https://s.adroll.com" :
                "http://a.adroll.com");
            scr.setAttribute('async', 'true');
            scr.type = "text/javascript";
            scr.src = host + "/j/roundtrip.js";
            ((document.getElementsByTagName('head') || [null])[0] ||
                document.getElementsByTagName('script')[0].parentNode).appendChild(scr);
        };
        if (window.addEventListener) {
            window.addEventListener('load', _onload, false);
        } else {
            window.attachEvent('onload', _onload)
        }
    }());
</script>
<!-- /AddRoll -->
<!-- Start Quantcast Tag -->
<script type="text/javascript">
    var _qevents = _qevents || [];
    (function() {
        var elem = document.createElement('script');
        elem.src = (document.location.protocol == "https:" ? "https://secure" : "http://edge") +
            ".quantserve.com/quant.js";
        elem.async = true;
        elem.type = "text/javascript";
        var scpt = document.getElementsByTagName('script')[0];
        scpt.parentNode.insertBefore(elem, scpt);
    })();
    _qevents.push({
        qacct: "p-gW27Kw8AMYE46"
    });
</script>
<noscript>
    <img src="../pixel.quantserve.com/pixel/p-gW27Kw8AMYE469476.gif?labels=_fp.event.Default" style="display: none;"
        border="0" height="1" width="1" alt="Quantcast" />
</noscript>
<!-- End Quantcast tag -->
<!-- Start of HubSpot Embed Code -->
<script type="text/javascript" id="hs-script-loader" async defer src="../js.hs-scripts.com/3951982.json"></script>
<!-- End of HubSpot Embed Code -->
<script data-obct type="text/javascript">
    /** DO NOT MODIFY THIS CODE**/ ! function(_window, _document) {
        var OB_ADV_ID = '00b896a30e1d2220993ab73ef443de899a';
        if (_window.obApi) {
            var toArray = function(object) {
                return Object.prototype.toString.call(object) === '[object Array]' ? object : [object];
            }

            ;
            _window.obApi.marketerId = toArray(_window.obApi.marketerId).concat(toArray(OB_ADV_ID));
            return;
        }
        var api = _window.obApi = function() {
            api.dispatch ? api.dispatch.apply(api, arguments) : api.queue.push(arguments);
        }

        ;
        api.version = '1.1';
        api.loaded = true;
        api.marketerId = OB_ADV_ID;
        api.queue = [];
        var tag = _document.createElement('script');
        tag.async = true;
        tag.src = '../amplify.outbrain.com/cp/obtp.js';
        tag.type = 'text/javascript';
        var script = _document.getElementsByTagName('script')[0];
        script.parentNode.insertBefore(tag, script);
    }(window, document);
    obApi('track', 'PAGE_VIEW');
</script><!-- Start Criteo Homepage tag -->
<script type="text/javascript" src="../static.criteo.net/js/ld/ld.js" async="true"></script>
<script type="text/javascript">
    window.criteo_q = window.criteo_q || [];
    var deviceType = /Mobile|iP(hone|od)|Android|BlackBerry|IEMobile|Silk/.test(navigator.userAgent) ?

        "m" : /iPad/.test(navigator.userAgent) ? "t" : "d";
    window.criteo_q.push({
        event: "setAccount",
        account: 21898
    }, {
        event: "setSiteType",
        type: deviceType
    }, {
        event: "setHashedEmail",
        email: [""]
    }, {
        event: "viewHome"
    });
</script>
<!-- End Criteo Homepage tag -->
<script type="text/javascript" src="assets/2343043f/js/bootstrap.bootbox.min1b4e.js?m=1536737766"></script>
<script type="text/javascript" src="assets/2343043f/js/bootstrap.minb0c7.js?m=1536737781"></script>
<script type="text/javascript" src="assets/c26d3fd7/js/es5-shim.min26d3.js?m=1536327699"></script>
<script type="text/javascript" src="assets/1c325eb8/js/instafeedv2.min8cdb.js?m=1596188684"></script>
<script type="text/javascript" src="assets/ca65e889/js/owl.carousela9e0.js?m=1536327774"></script>
<script type="text/javascript"
    src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.4.2/js/swiper.jquery.minba8c.js?m=1661370796"></script>
<script type="text/javascript" src="libs/fancybox/jquery.fancybox.minefa0.js?m=1661331896"></script>
<script type="text/javascript"
    src="themes/wp_exr/libs/bootstrap-datepicker/dist/js/bootstrap-datepicker.minefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/libs/superfish/dist/js/superfish.minefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/libs/waypoints/lib/jquery.waypoints.minefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/libs/counter-up/jquery.counterupefa0.js?m=1661331896"></script>
<script type="text/javascript"
    src="themes/wp_exr/libs/youtube-background/src/jquery.youtubebackgroundefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/js/jquery.readyLoadefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/js/lazy.load.minefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/js/sweetalert2.all.minefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/js/mainefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/js/facebook_trackingefa0.js?m=1661331896"></script>
<script type="text/javascript" src="themes/wp_exr/js/jquery.visible.minefa0.js?m=1661331896"></script>
<script type="text/javascript" src="libs/cookie/jquery.cookieefa0.js?m=1661331896"></script>
<script type="text/javascript" src="assets/c94e2d0d/summary6eee.js?m=1574410013"></script>
<script type="text/javascript" src="assets/1ce650c5/js/subscribeemailbe9e.js?m=1536327700"></script>
<script type="text/javascript" src="assets/9fcfe31/js/jquery.uniform.min528a.js?m=1536327706"></script>
<script type="text/javascript" src="assets/9fcfe31/js/custom528a.js?m=1536327706"></script>
<script type="text/javascript" src="assets/9fcfe31/js/idle-timer.min528a.js?m=1536327706"></script>
<?php /**PATH E:\Development\RogProjects\fiverr\saad\resources\views/template/script.blade.php ENDPATH**/ ?>